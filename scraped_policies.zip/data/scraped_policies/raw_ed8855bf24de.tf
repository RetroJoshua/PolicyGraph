resource "aws_iam_policy" "mediapackage-rw" {
  name = "mediapackage-rw-${var.env}"
  path = "/mediapackage-vod/"

  tags = {
    Environment = var.env
  }
  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement" : [
        {
          "Sid" : "VisualEditor0",
          "Effect" : "Allow",
          "Action" : [
            "mediapackage-vod:DeleteAsset",
            "mediapackage-vod:DescribePackagingConfiguration",
            "mediapackage-vod:ListTagsForResource",
            "mediapackage-vod:ListPackagingConfigurations",
            "mediapackage-vod:ListAssets",
            "mediapackage-vod:CreateAsset",
            "mediapackage-vod:ListPackagingGroups",
            "mediapackage-vod:DescribePackagingGroup",
            "mediapackage-vod:UntagResource",
            "mediapackage-vod:DescribeAsset",
            "mediapackage-vod:TagResource"
          ],
          "Resource" : "*"
        }
      ]
    }
  )
}