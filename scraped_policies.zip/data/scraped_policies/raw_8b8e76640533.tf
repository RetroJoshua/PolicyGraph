data "aws_iam_policy_document" "external_services_server" {
#   statement {
#     sid    = "ConsulAutoJoin"
#     effect = "Allow"

#     actions = ["ec2:DescribeInstances"]

#     resources = ["*"]
#   }
# }