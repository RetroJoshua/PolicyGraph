data "aws_iam_policy_document" "assume-from-mfa" {
  statement {
    sid     = "TfCustomPolicyAllowAssumeFromMFA"
    effect  = "Allow"
    actions = ["sts:AssumeRole"]

    principals {
      type = "AWS"

      # Any mfa authenticated user from this account. AWS don't allow using groups as
      # principals identifiers. So we don't filter role usage from there.
      # To restrict roles usage, on a per role basis, we just define, for each role, a
      # policy, allowing "assume this $role", and attach that to the relevant groups
      # (our groups don't have a generic "assume any role" policy).
      identifiers = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"]
    }

    condition {
      test     = "Bool"
      variable = "aws:MultiFactorAuthPresent"
      values   = ["true"]
    }
  }
}