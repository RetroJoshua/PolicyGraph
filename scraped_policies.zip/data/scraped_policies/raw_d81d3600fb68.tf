resource "aws_iam_policy" "fis_custom" {
#   name = "${var.service}-fis-custom"
#   policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Effect   = "Deny"
#         Action   = "*"
#         Resource = "*"
#         Condition = {
#           "StringNotEqualsIfExists" = {
#             "aws:ResourceTag/fis/service" = "aws-fis-newbie"
#           }
#         }
#       }
#     ]
#   })
# }