resource "aws_iam_role_policy" "event_target" {
  name   = "inline1"
  role   = aws_iam_role.event_target.id
  policy = data.aws_iam_policy_document.event_target.json
}