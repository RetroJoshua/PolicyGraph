resource "aws_iam_role" "tfc_role" {
  name               = "tfc-role"
  assume_role_policy = data.aws_iam_policy_document.tfc_assume_role_policy.json
}