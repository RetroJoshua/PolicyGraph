resource "aws_iam_policy" "alb_iam_policy" {
  name        = "alb_iam_policy-${var.infra_name}"
  description = "alb policy"
  policy      = file("${path.module}/policy/alb_iam_policy.json")
  depends_on = [ aws_iam_openid_connect_provider.oidc_provider ]
}