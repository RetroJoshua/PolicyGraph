resource "aws_iam_policy" "snowalert_decrypt" {
  name        = "${var.name}-snowalert_decrypt"
  description = "${var.name} SnowAlert decrypt policy"

  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": {
    "Effect": "Allow",
    "Action": "kms:Decrypt",
    "Resource": "${var.kms_key_arn}"
  }
}
EOF
}