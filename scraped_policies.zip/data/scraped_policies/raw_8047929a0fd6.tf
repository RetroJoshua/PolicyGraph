data "aws_iam_policy_document" "order_queue_policy" {
  statement {
    effect    = "Allow"
    actions   = ["sqs:*"]
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
    resources = [aws_sqs_queue.order_queue.arn]
  }
}