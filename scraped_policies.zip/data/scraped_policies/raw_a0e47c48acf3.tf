data "aws_iam_policy_document" "ssm_logs_s3_write" {
#   count    = var.enable_test1_vpc ? 1 : 0
#   provider = aws.test1

#   statement {
#     effect    = "Allow"
#     actions   = ["s3:PutObject"]
#     resources = ["${aws_s3_bucket.ssm_logs[0].arn}/*"]
#   }

#   statement {
#     effect    = "Allow"
#     actions   = ["s3:GetEncryptionConfiguration"]
#     resources = ["*"]
#   }
# }