resource "aws_iam_role" "deploy" {
  name                  = var.deploy_role_name
  assume_role_policy    = data.aws_iam_policy_document.github_oidc_assume_role.json
  description           = "Role assumed by GitHub Actions to deploy ECS/ECR/Dynamo/Logs infra for CoC bots"
  force_detach_policies = true
}