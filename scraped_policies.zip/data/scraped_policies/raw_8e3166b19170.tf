data "aws_iam_policy_document" "cloudformation_permission" {
  # Allow CloudFormation to publish status changes to the SNS queue
  statement {
    effect = "Allow"
    actions = [
      "sns:Publish"
    ]
    resources = [module.deploy_controller.sns_topic_arn]
  }

  # Allow CloudFormation to access the lambda content
  statement {
    effect = "Allow"
    actions = [
      "s3:GetObject"
    ]
    resources = [
      module.statics_deploy.static_bucket_arn,
      "${module.statics_deploy.static_bucket_arn}/*"
    ]
  }

  # Stack creation
  statement {
    effect = "Allow"
    actions = [
      # TODO: Restrict the API Gateway action more
      "apigateway:*",
      "iam:CreateRole",
      "iam:GetRole",
      "iam:GetRolePolicy",
      "iam:PassRole",
      "iam:PutRolePolicy",
      "iam:TagRole",
      "lambda:AddPermission",
      "lambda:CreateFunction",
      "lambda:CreateFunctionUrlConfig",
      "lambda:GetFunctionUrlConfig",
      "lambda:GetFunction",
      "lambda:TagResource",
      "logs:CreateLogGroup",
      "logs:PutRetentionPolicy",
      "logs:TagLogGroup"
    ]
    resources = ["*"]
  }

  # Stack deletion
  statement {
    effect = "Allow"
    actions = [
      "apigateway:*",
      "iam:DeleteRole",
      "iam:DeleteRolePolicy",
      "iam:UntagRole",
      "lambda:DeleteFunction",
      "lambda:DeleteFunctionUrlConfig",
      "lambda:RemovePermission",
      "lambda:UntagResource",
      "logs:DeleteLogGroup",
      "logs:DeleteRetentionPolicy",
      "logs:UntagLogGroup"
    ]
    resources = ["*"]
  }
}