resource "aws_iam_role" "asg_lifecycle" {
  name               = "${var.name_prefix}-asg-lifecycle"
  assume_role_policy = data.aws_iam_policy_document.asg_lifecycle_assume.json
  tags               = local.common_tags
}