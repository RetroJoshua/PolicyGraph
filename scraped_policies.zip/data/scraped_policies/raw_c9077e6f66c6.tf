resource "aws_iam_policy" "deploy" {
  name        = "coc-bot-deploy-policy"
  description = "Permissions for CI/CD to manage ECS/ECR/Dynamo/Logs and IAM for CoC bots"
  policy      = data.aws_iam_policy_document.deploy_permissions.json
}