resource "aws_iam_role_policy" "iot_sqs_policy" {
  name = "iot_sqs_policy"
  role = aws_iam_role.iot_to_sqs_role.id
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action = "sqs:SendMessage",
        Effect = "Allow",
        Resource = aws_sqs_queue.parcel_events.arn
      }
    ]
  })
}