resource "aws_iam_role_policy" "log" {
  count  = var.enabled == "true" ? 1 : 0
  name   = module.vpc_label.id
  role   = aws_iam_role.log.id
  policy = data.aws_iam_policy_document.log.json
}