resource "aws_iam_role" "kinesis_analytics_execution_role" {
  assume_role_policy = jsonencode({
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "kinesisanalytics.amazonaws.com"
      }
    }]
    Version = "2012-10-17"
  })
  description = "Allows Kinesis Analytics to call AWS services on your behalf."
  name        = "KinesisAnalyticsExecutionRole"
  path        = "/"
}