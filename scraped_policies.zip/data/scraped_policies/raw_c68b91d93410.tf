data "aws_iam_policy_document" "allow_mediaconvert_access" {
  statement {
    principals {
      type        = "Service"
      identifiers = ["mediaconvert.amazonaws.com"]
    }

    actions = [
      "s3:GetObject"
    ]

    resources = [
      "${aws_s3_bucket.source_video.arn}/*",
    ]
  }
}