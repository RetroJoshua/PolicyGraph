data "aws_iam_policy_document" "test_store_bucket_policy" {
  # Deny any request not using TLS/HTTPS
  statement {
    sid    = "DenyNonSecureTransport"
    effect = "Deny"

    principals {
      type        = "*"
      identifiers = ["*"]
    }
    actions = ["s3:*"]
    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
    resources = [aws_s3_bucket.test_store.arn, "${aws_s3_bucket.test_store.arn}/*"]
  }

  #Deny any request from anyone other than the ec2 resource specified
  statement {
    sid    = "DenyNonEc2Access"
    effect = "Deny"
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    actions   = ["s3:*"]
    resources = [aws_s3_bucket.test_store.arn, "${aws_s3_bucket.test_store.arn}/*"]
    condition {
      test = "StringNotEquals"
      variable = "aws:PrincipalArn"
      values = [
        aws_iam_role.ec2_instance_profile.arn,
        data.aws_caller_identity.current.arn
      ]
    }
  }

  #Deny Non-Encrypted data sent to s3bucket
  statement {
    sid    = "DenyUnencryptedObjects"
    effect = "Deny"
    principals {
      type        = "*"
      identifiers = ["*"]
    }
    actions   = ["s3:PutObject"]
    resources = [aws_s3_bucket.test_store.arn, "${aws_s3_bucket.test_store.arn}/*"]
    condition {
      test     = "StringNotEquals"
      variable = "s3:x-amz-server-side-encryption"
      values   = ["AES256"]
    }
  }

  depends_on = [aws_s3_bucket.test_store, aws_instance.data_pipeline]
}