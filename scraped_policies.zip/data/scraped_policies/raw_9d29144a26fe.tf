resource "aws_iam_role_policy" "ssm_complete_lifecycle" {
#   name   = "complete-lifecycle"
#   role   = aws_iam_role.ssm.id
#   policy = data.aws_iam_policy_document.complete_lifecycle.json
# }