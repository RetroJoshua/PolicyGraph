resource "aws_iam_role_policy" "s3_policy" {
  role = aws_iam_role.ec2_s3_role.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Action = ["s3:*"]
      Resource = [
        "arn:aws:s3:::wp-media-prod-bucket",
        "arn:aws:s3:::wp-media-prod-bucket/*"
      ]
    }]
  })
}