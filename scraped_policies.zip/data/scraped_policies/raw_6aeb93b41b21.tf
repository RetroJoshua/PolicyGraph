resource "aws_iam_role_policy" "IAMPolicy" {
  policy = data.aws_iam_policy_document.es_access.json
  role   = aws_iam_role.auth_role.name
}