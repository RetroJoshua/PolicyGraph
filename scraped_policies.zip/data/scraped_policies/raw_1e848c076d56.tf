resource "aws_iam_role" "lf_data_access" {
  count = var.create_lf_resource && var.create_lf_data_access_role ? 1 : 0
  name  = "${local.instance_alias}-lf-data-access-role-${var.aws_region}"

  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "lakeformation.amazonaws.com"
      },
      "Action": [ "sts:AssumeRole", "sts:SetContext" ]
    }
  ]
}
EOF

  tags = var.apiary_tags
}