resource "aws_iam_policy" "s3_access_policy" {
  depends_on = [aws_s3_bucket.my_bucket]
  name        = "${var.aws_region}_${local.client_name_no_spaces}_S3_Policy"
  description = "Policy to allow S3 access"
  tags = local.tags.default
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action = ["s3:ListBucket", "s3:GetObject", "s3:PutObject", "s3:DeleteObject"],
        Effect = "Allow",
        Resource = [
          aws_s3_bucket.my_bucket.arn,
          "${aws_s3_bucket.my_bucket.arn}/*"
        ]
      }
    ]
  })
}