resource "aws_iam_policy" "replication_policy" {
  name   = "replication_policy"
  policy = data.aws_iam_policy_document.replication_policy_document.json
}