resource "aws_iam_role" "efs_csi_driver" {
  name               = "${aws_eks_cluster.eks_cluster.name}-efs-csi-driver"
  assume_role_policy = data.aws_iam_policy_document.efs_csi_driver.json
}