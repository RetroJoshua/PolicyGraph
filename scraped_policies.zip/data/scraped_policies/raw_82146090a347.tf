data "aws_iam_policy_document" "allow_backup" {
  statement {
    effect = "Allow"

    resources = [ aws_s3_bucket.dbbackup.arn, "${aws_s3_bucket.dbbackup.arn}/*"]

    actions = ["s3:PutObject", "s3:GetObject", "s3:ListBucket"]
  }
  statement {
    effect = "Allow"

    resources = [aws_ssm_parameter.database_password.arn]

    actions = ["ssm:GetParameter", "kms:Decrypt"]
  }
}