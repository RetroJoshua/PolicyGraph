resource "aws_iam_policy" "master_db_pw_secret" {
  name        = "${var.app_name}-db-master-pw-secret"
  description = "Allows retrieval of the DB master password from Secrets Manager"
  policy      = data.aws_iam_policy_document.master_db_pw_secret.json

  tags = var.db_tags
}