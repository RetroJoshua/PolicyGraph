resource "aws_iam_role" "cloudwatch" {
  count = var.enabled && local.log_cloudwatch_creation_enabled ? 1 : 0

  name               = "${module.label.id}-cw"
  assume_role_policy = data.aws_iam_policy_document.flow_log_cw_assume[0].json
  tags               = module.label.tags
}