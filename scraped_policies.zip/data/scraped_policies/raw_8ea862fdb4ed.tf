resource "aws_iam_role" "backstage" {
  name               = "${local.name}-task-execution-role"
  assume_role_policy = data.aws_iam_policy_document.ecs_task_assume_role.json
  inline_policy {
    name   = "policy-${local.name}-secrets"
    policy = data.aws_iam_policy_document.secrets_manager_access.json
  }
}