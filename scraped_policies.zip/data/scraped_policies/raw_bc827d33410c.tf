resource "aws_iam_role" "iam_role" {
    name               = "${local.namespace}-tf-assume-role"
    assume_role_policy = jsonencode({
        "Version": "2012-10-17",
        "Statement": [
        {  
        "Action": "sts:AssumeRole",
        "Principal": {
            "AWS": local.principal_arns
        },
        "Effect": "Allow"
        }
    ]
    })

    tags = {
        ResourceGroup = local.namespace
    }
}