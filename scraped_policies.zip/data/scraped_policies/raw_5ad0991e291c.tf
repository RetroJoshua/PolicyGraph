resource "aws_iam_policy" "replication" {
  name   = "iam-role-policy-replica"
  policy = data.aws_iam_policy_document.replication.json
}