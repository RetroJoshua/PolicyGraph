data "aws_iam_policy_document" "backup_put_objects" {
  count = var.create_backup_bucket ? 1 : 0

  statement {
    effect    = "Allow"
    actions   = ["s3:ListBucket", "s3:GetBucketLocation"]
    resources = [aws_s3_bucket.backups[0].arn]
  }

  statement {
    effect    = "Allow"
    actions   = ["s3:DeleteObject", "s3:GetObject", "s3:PutObject"]
    resources = ["${aws_s3_bucket.backups[0].arn}/*"]
  }
}