resource "aws_iam_role_policy" "ecs_iam_role_policy" {
  policy = data.aws_iam_policy_document.ecs_iam_policy.json
  name   = "ecs-assume-role"
  role   = aws_iam_role.ecs_iam_role.id
}