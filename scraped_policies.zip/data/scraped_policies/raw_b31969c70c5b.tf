resource "aws_iam_role_policy" "ec2_sns_policy" {
#   name = "ec2_sns_publish_policy"
#   role = aws_iam_role.ec2_cloudwatch_role.id
#
#   policy = jsonencode({
#     Version = "2012-10-17"
#     Statement = [
#       {
#         Effect = "Allow"
#         Action = [
#           "sns:Publish",
#           "sns:GetTopicAttributes"
#         ]
#         Resource = [aws_sns_topic.user_verification.arn]
#       },
#       {
#         Effect = "Allow"
#         Action = [
#           "kms:Decrypt",
#           "kms:GenerateDataKey"
#         ]
#         Resource = [aws_kms_key.secrets_key.arn]
#       }
#     ]
#   })
# }