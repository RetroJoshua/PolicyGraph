resource "aws_iam_role" "app_db_user_func" {
  name               = "${var.app_name}-db-user-func"
  assume_role_policy = data.aws_iam_policy_document.func_assume_role_policy.json

  tags = var.db_tags
}