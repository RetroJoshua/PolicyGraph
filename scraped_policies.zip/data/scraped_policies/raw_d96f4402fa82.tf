data "aws_iam_policy_document" "autoscaling_trust" {
#   statement {
#     actions = ["sts:AssumeRole"]
#     principals {
#       type        = "Service"
#       identifiers = ["autoscaling.amazonaws.com"]
#     }
#   }
# }