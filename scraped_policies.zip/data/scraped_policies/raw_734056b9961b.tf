data "aws_iam_policy_document" "s3_bucket_access" {
  statement {
    actions = [
      "s3:ListBucket",
      "s3:GetBucketLocation",
      "s3:ListBucketMultipartUploads"
    ]
    resources = [
      "arn:aws:s3:::${lower(var.name)}-backups",
      "arn:aws:s3:::${lower(var.name)}-blobs",
      "arn:aws:s3:::${lower(var.name)}-logs",
      "arn:aws:s3:::${lower(var.name)}-registry"
    ]
  }

  statement {
    actions = [
      "s3:PutObject",
      "s3:GetObject",
      "s3:DeleteObject",
      "s3:ListMultipartUploadParts",
      "s3:AbortMultipartUpload"
    ]
    resources = [
      "arn:aws:s3:::${lower(var.name)}-backups",
      "arn:aws:s3:::${lower(var.name)}-blobs",
      "arn:aws:s3:::${lower(var.name)}-logs",
      "arn:aws:s3:::${lower(var.name)}-registry"
    ]
  }

}