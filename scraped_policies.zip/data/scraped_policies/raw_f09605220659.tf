resource "aws_iam_role" "lambda_fanout_function" {
  assume_role_policy = jsonencode({
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "lambda.amazonaws.com"
      }
    }]
    Version = "2012-10-17"
  })
  description          = "Allows Lambda functions to call AWS services on your behalf."
  max_session_duration = 3600
  name                 = "LambdaFanoutFunctionRole"
  path                 = "/"
}