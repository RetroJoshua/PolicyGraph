resource "aws_iam_user_policy" "nas_send_emails" {
  policy = data.aws_iam_policy_document.nas_ses_policy.json
  user   = aws_iam_user.nas.name
}