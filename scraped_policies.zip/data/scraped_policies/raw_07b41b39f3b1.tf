data "aws_iam_policy_document" "flight_doc_cognito" {
  statement {
    resources = ["arn:aws:execute-api:us-east-1:${data.aws_caller_identity.current.account_id}:${aws_apigatewayv2_api.main.id}/*/*/amateur/flightdoc"]
    actions   = ["execute-api:*"]
  }
}