data "aws_iam_policy_document" "auth_cognito_policy" {
  statement {
    resources = ["*"]

    actions = [
      "mobileanalytics:PutEvents",
      "cognito-sync:*",
      "cognito-identity:*",
    ]
  }
}