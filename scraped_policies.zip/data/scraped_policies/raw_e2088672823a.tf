data "aws_iam_policy_document" "deployment_bucket" {
  count = "${var.project_artifacts["type"] == "S3" ? var.count : 0}"

  statement {
    sid     = "CodeBuild"
    actions = ["s3:*"]

    resources = [
      "${join(",", data.aws_s3_bucket.deployment_bucket.*.arn)}",
      "${join(",", data.aws_s3_bucket.deployment_bucket.*.arn)}/*",
    ]

    principals {
      identifiers = ["${join(",", aws_iam_role.deployment_role.*.arn)}"]
      type        = "AWS"
    }
  }
}