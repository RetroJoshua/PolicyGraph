resource "aws_iam_role_policy" "consumer_policy" {
  name = "sqs-consumer-policy"
  role = aws_iam_role.consumer_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action   = ["sqs:ReceiveMessage", "sqs:DeleteMessage", "sqs:GetQueueAttributes"]
      Effect   = "Allow"
      Resource = aws_sqs_queue.order_queue.arn
    }]
  })
}