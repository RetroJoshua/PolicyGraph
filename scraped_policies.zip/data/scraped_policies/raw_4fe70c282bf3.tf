resource "aws_iam_role" "ecs_iam_role" {
  name = "iam-role-ecs"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid : "",
        Effect : "Allow",
        Principal = {
          Service = "ecs.amazonaws.com"
        },
        Action : [
          "sts:AssumeRole"
        ],
      }
    ]
  })
}