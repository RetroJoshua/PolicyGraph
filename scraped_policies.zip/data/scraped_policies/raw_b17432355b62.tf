resource "aws_iam_role" "iam_role" {
    name               = "${local.namespace}-tf-assume-role"
    assume_role_policy = local.assume_role_policy_document
}