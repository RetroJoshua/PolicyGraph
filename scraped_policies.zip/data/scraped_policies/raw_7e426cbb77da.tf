resource "aws_iam_role_policy" "cloud_watch" {
  name = "DemoApiCloudWatchLoggingPolicy"

  role = "${aws_iam_role.assumed_lambda_exec.id}"

  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogGroup",
                "logs:CreateLogStream",
                "logs:PutLogEvents"
            ],
            "Resource": "*"
        }
    ]
}
EOF
}