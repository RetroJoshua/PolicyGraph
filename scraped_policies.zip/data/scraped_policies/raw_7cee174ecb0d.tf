data "aws_iam_policy_document" "assets_bucket" {
  statement {
    sid    = "ReadWrite"
    effect = "Allow"
    actions = [
      "s3:ListBucket*",
      "s3:Get*",
      "s3:PutObject*",
      "s3:DeleteObject*"
    ]
    principals {
      type = "AWS"
      identifiers = [
        aws_iam_role.bastion.arn,
        aws_iam_role.eks_node_group.arn
      ]
    }
    resources = [
      aws_s3_bucket.assets.arn,
      "${aws_s3_bucket.assets.arn}/*"
    ]
  }

  statement {
    sid    = "ReadOnly"
    effect = "Allow"
    actions = [
      "s3:ListBucket*",
      "s3:Get*"
    ]
    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.ecs_task.arn]
    }
    resources = [
      aws_s3_bucket.assets.arn,
      "${aws_s3_bucket.assets.arn}/*"
    ]
  }
}