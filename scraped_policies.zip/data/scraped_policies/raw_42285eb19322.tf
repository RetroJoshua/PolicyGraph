resource "aws_iam_policy" "dev_policy" {
  name = "${local.cluster_name}-k8sDevs-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "eks:DescribeNodegroup",
          "eks:ListNodegroups",
          "eks:DescribeCluster",
          "eks:AccessKubernetesApi",
          "ssm:GetParameter",
          "eks:ListClusters",
          "eks:ListUpdates",
          "eks:ListFargateProfiles"
        ],
        Resource = "*"
      }
    ]
  })
}