resource "aws_iam_role_policy" "scheduled_task_cloudwatch_policy" {
  name = "ecs-cloudwatch-policy"
  role = aws_iam_role.scheduled_task_cloudwatch.id
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "ecs:RunTask"
        ],
        Resource = [
          replace(aws_ecs_task_definition.task.arn, "/:\\d+$/", ":*")
        ]
      },
      {
        Effect = "Allow",
        Action = "iam:PassRole",
        Resource = [
          "*"
        ]
      }
    ]
  })
}