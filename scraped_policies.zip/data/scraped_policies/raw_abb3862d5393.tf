resource "aws_iam_policy" "sample-s3" {
  name   = "s3-sample-terraform"
  policy = data.aws_iam_policy_document.sample-s3.json
}