resource "aws_iam_role" "monitoring" {
  name               = "${local.resource_name}-monitoring"
  assume_role_policy = data.aws_iam_policy_document.monitoring_assume.json
  tags               = local.tags
}