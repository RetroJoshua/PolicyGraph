resource "aws_iam_role" "ccf_api_role" {
  assume_role_policy = data.aws_iam_policy_document.assume_role_policy.json
  name               = "ccf-api-role"
}