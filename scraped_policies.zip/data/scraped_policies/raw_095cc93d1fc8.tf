resource "aws_iam_policy" "external_services_server" {
#   name   = "cmelgreen-external_services-test"
#   policy = data.aws_iam_policy_document.external_services_server.json
# }