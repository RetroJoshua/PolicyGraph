resource "aws_iam_policy" "snowalert_execution" {
  name        = "${var.name}-snowalert_execution"
  description = "${var.name} SnowAlert execution policy"

  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": {
    "Action": [
      "ecr:GetAuthorizationToken",
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "cloudwatch:PutMetricData"
    ],
    "Effect": "Allow",
    "Resource": "*"
  }
}
EOF
}