resource "aws_iam_policy" "master_node_policy" {
  count  = length(local.master_policies)
  name   = "${local.master_policies[count.index][0]}_policy"
  policy = file(local.master_policies[count.index][1])
}