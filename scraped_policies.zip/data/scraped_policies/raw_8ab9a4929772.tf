resource "aws_iam_role" "ssm" {
#   name               = "${var.name}-ssm"
#   assume_role_policy = data.aws_iam_policy_document.ssm_trust.json
# }