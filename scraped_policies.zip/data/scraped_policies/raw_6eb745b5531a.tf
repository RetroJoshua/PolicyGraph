resource "aws_iam_role_policy" "codepipeline_policy" {
  count = "${var.ci_container_name != "" ? 1 : 0}"

  name = "tf-${var.name}-pipeline"
  role = "${aws_iam_role.codepipeline_role[0].id}"
  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
      {
        "Effect": "Allow",
        "Action": "*",
        "Resource": "*"
      }
    ]
}
EOF
}