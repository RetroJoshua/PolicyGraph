resource "aws_iam_role" "lambda_sqs_to_sns" {
  count       = var.send_events_to_sns ? 1 : 0
  name_prefix = "${local.module_name}-lambda-sqs-sns"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "lambda.amazonaws.com"
        }
      }
    ]
  })
}