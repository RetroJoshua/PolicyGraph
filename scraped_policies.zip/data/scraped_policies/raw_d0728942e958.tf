resource "aws_iam_role_policy" "autoscaling_publish_notifications" {
#   name   = "sns-publish"
#   role   = aws_iam_role.autoscaling_lifecycle.id
#   policy = data.aws_iam_policy_document.publish_notifications.json
# }