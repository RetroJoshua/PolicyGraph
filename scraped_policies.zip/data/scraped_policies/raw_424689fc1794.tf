resource "aws_iam_user_policy" "svc_pipeline_policy" {
  name    = "VAST2SGEI_pipeline_policy-${terraform.workspace}"
  user    = aws_iam_user.svc_pipeline.name
  policy  =  <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": [
        "ecs:*",
        "ecr:*",
        "iam:PassRole"
      ],
      "Effect": "Allow",
      "Resource": [
          "*"
      ]
    },
    {
      "Action": [
        "cloudfront:CreateInvalidation"
      ],
      "Effect": "Allow",
      "Resource": [
          "*"
      ]
    }
  ]
}
EOF
}