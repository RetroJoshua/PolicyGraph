resource "aws_iam_role_policy" "lambda_secretsmanager_policy" {
  name = "lambda-secretsmanager-policy"
  role = aws_iam_role.lambda_execution_role.name
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action = [
          "secretsmanager:GetSecretValue"
        ]
        Effect   = "Allow"
        Resource = aws_secretsmanager_secret.mailgun_api_key.arn
      },
      {
        Action = [
          "kms:Decrypt"
        ]
        Effect   = "Allow"
        Resource = aws_kms_key.secrets_manager_key.arn
      },
    ]
  })
}