data "aws_iam_policy_document" "yolo_detect_worker_task" {
  statement {
    sid     = "S3ReadFramesAndModels"
    actions = ["s3:GetObject"]
    resources = [
      "${aws_s3_bucket.videos.arn}/${trimsuffix(local.embedding_frame_prefix, "/")}/*",
      "${aws_s3_bucket.videos.arn}/${local.yolo_models_prefix}/*",
    ]
  }

  statement {
    sid       = "ReadDbSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }
}