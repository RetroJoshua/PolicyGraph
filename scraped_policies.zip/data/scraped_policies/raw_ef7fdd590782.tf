resource "aws_iam_policy" "lbc" {
  name        = "${local.name}-lbc"
  description = "IAM policy for AWS Load Balancer Controller"
  policy      = data.http.lbc_iam_policy.response_body

  tags = local.tags
}