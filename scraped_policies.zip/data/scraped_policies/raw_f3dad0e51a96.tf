resource "aws_iam_role" "ssm" {
  name               = "SSMInstance"
  assume_role_policy = data.aws_iam_policy_document.ssm_trust_policy.json
}