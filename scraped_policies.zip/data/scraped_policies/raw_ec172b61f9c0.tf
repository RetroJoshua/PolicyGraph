data "aws_iam_policy" "func_vpc_access" {
  name = "AWSLambdaVPCAccessExecutionRole"
}