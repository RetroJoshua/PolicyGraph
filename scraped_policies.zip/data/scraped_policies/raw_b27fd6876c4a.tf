resource "aws_iam_policy" "secretsmanager_policy" {
  name        = "${var.nombre_lab}_SecretsManagerPolicy"
  description = "Permisos para acceder a los secretos de PostgreSQL en Secrets Manager"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement : [
      {
        Effect : "Allow",
        Action : [
          "secretsmanager:GetSecretValue"
        ],
        Resource : [
          "arn:aws:secretsmanager:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:secret:username_*",
          "arn:aws:secretsmanager:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:secret:password_*"
        ]
      }
    ]
  })
}