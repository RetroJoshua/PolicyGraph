data "aws_iam_policy_document" "ec2_for_ssm" {
  source_json = data.aws_iam_policy.ec2_for_ssm.policy

  statement {
    effect    = "Allow"
    resources = ["*"]

    // AmazonSSMManagedInstanceCore ポリシーをベースにし、S3バケットとCloudWatch Logsへの書き込み権限を付与する
    // SSMパラメータストアとECRへの参照権限を追加することでEC2上で「ECRに格納したイメージのdocker pull」と「SSM
    // パラメータストアから設定情報を注入したコンテナの起動」を実現できる
    actions = [
      "s3:PutObject",
      "logs:PutLogEvents",
      "logs:CreateLogStream",
      "ecr:GetAuthorizationToken",
      "ecr:BatchCheckLayerAvailability",
      "ecr:GetDownloadUrlForLayer",
      "ecr:BatchGetImage",
      "ssm:GetParameter",
      "ssm:GetParameters",
      "ssm:GetParametersByPath",
      "kms:Decrypt",
    ]
  }
}