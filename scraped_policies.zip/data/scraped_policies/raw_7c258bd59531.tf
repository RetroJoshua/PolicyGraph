data "aws_iam_policy_document" "deploy_permissions" {
  // ECR push/build + repo management
  statement {
    actions   = ["ecr:*"]
    resources = ["*"]
  }

  // ECS cluster/service/task definition management
  statement {
    actions   = ["ecs:*"]
    resources = ["*"]
  }

  // DynamoDB table management (verifications + giveaways)
  statement {
    actions   = ["dynamodb:*"]
    resources = ["*"]
  }

  // CloudWatch Logs groups and streams
  statement {
    actions   = ["logs:*"]
    resources = ["*"]
  }

  // EC2 security groups used by ECS services
  statement {
    actions = [
      "ec2:CreateSecurityGroup",
      "ec2:DeleteSecurityGroup",
      "ec2:AuthorizeSecurityGroupEgress",
      "ec2:RevokeSecurityGroupEgress",
      "ec2:DescribeSecurityGroups",
      "ec2:DescribeVpcs",
      "ec2:DescribeSubnets",
      "ec2:CreateTags",
      "ec2:DeleteTags"
    ]
    resources = ["*"]
  }

  // IAM to create task role and inline policies + PassRole to ECS
  statement {
    actions = [
      "iam:CreateRole",
      "iam:DeleteRole",
      "iam:TagRole",
      "iam:UntagRole",
      "iam:PutRolePolicy",
      "iam:DeleteRolePolicy",
      "iam:AttachRolePolicy",
      "iam:DetachRolePolicy",
      "iam:GetRole",
      "iam:ListAttachedRolePolicies",
      "iam:ListRolePolicies",
      "iam:PassRole"
    ]
    resources = [
      "*"
    ]
  }
}