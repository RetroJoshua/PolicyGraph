resource "aws_iam_role" "instance_role" {
  name               = "InstanceRole"
  assume_role_policy = data.aws_iam_policy_document.ec2_assume_role_policy.json
}