data "aws_iam_policy_document" "oai_spa_policy" {
  statement {
    actions = ["s3:GetObject"]
    principals {
      type        = "AWS"
      identifiers = ["${aws_cloudfront_origin_access_identity.oai_spa.iam_arn}"]
    }
    resources = ["${aws_s3_bucket.spa-app-bkt.arn}/*"]
  }
}