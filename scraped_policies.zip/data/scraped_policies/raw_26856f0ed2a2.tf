resource "aws_iam_role_policy" "codebuild_policy" {
  count = "${var.ci_container_name != "" ? 1 : 0}"

  role   = "${aws_iam_role.codebuild_role[0].name}"
  policy = <<POLICY
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": "*",
      "Resource": "*"
    }
  ]
}
POLICY
}