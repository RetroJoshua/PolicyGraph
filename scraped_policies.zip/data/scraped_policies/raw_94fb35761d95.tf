resource "aws_iam_role_policy" "sso_sagemaker_s3_policy" {
  count = var.enable_sso ? 1 : 0
  name  = "${var.domain_name}-sso-s3-policy"
  role  = aws_iam_role.sso_sagemaker_execution_role[0].id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "s3:GetObject",
          "s3:PutObject",
          "s3:DeleteObject",
          "s3:ListBucket"
        ]
        Resource = [
          "${aws_s3_bucket.sagemaker_bucket.arn}",
          "${aws_s3_bucket.sagemaker_bucket.arn}/*"
        ]
      }
    ]
  })
}