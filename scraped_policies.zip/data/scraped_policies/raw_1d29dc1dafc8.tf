resource "aws_iam_role" "cluster" {
  name = "EKSClusterRole-${var.cluster_name}"

  assume_role_policy    = data.aws_iam_policy_document.cluster_assume_role.json
  permissions_boundary  = var.permissions_boundary
  force_detach_policies = true
}