resource "aws_iam_role" "stream_raw_to_s3" {
  assume_role_policy = jsonencode({
    Statement = [{
      Action = "sts:AssumeRole"
      Effect = "Allow"
      Principal = {
        Service = "firehose.amazonaws.com"
      }
    }]
    Version = "2012-10-17"
  })
  description           = "Allows Firehose to transform and deliver data to your destinations using CloudWatch Logs, Lambda, and S3 on your behalf."
  force_detach_policies = false
  max_session_duration  = 3600
  name                  = "FireHoseRole"
  name_prefix           = null
  path                  = "/"
  permissions_boundary  = null

}