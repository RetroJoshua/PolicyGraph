resource "aws_iam_policy" "cloudformation_permission" {
  name        = "${var.deployment_name}_cf-control"
  description = "Managed by Terraform Next.js"
  policy      = data.aws_iam_policy_document.cloudformation_permission.json

  tags = var.tags
}