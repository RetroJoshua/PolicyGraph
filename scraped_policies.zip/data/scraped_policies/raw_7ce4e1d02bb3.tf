data "aws_iam_policy_document" "snapshots" {
  count = var.aws_snapshots ? 1 : 0

  statement {
    sid       = ""
    effect    = "Allow"
    resources = ["*"]
    actions = [
      "ec2:CreateSnapshot",
      "ec2:DeleteSnapshot",
      "ec2:DescribeVolumes",
      "ec2:DescribeSnapshots",
    ]
  }

  statement {
    sid       = ""
    effect    = "Allow"
    resources = ["arn:aws:ec2:*::snapshot/*"]
    actions = [
      "ec2:CreateTags",
    ]
  }
}