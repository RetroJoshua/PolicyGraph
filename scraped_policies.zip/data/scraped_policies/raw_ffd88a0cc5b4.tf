data "aws_iam_policy_document" "lifecycle_topic" {
  statement {
    sid     = "AllowAsgPublish"
    actions = ["sns:Publish"]
    principals {
      type        = "Service"
      identifiers = ["autoscaling.amazonaws.com"]
    }
    resources = [aws_sns_topic.lifecycle.arn]
  }
}