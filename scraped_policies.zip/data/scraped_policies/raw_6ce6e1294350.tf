data "aws_iam_policy_document" "sprints_database_management" {
  statement {
    effect = "Allow"
    actions = [
      "rds:StartDBInstance",
      "rds:StopDBInstance",
      "rds:RebootDBInstance",
      "rds:DeleteDBInstance",
      "rds:ModifyDBInstance",
      "rds:DescribeDBInstances",
      "rds:CreateDBSnapshot"
    ]
    resources = [
      "arn:aws:rds:${var.region}:${var.account_id}:db:*"
    ]
  }
}