data "aws_iam_policy_document" "lambda_get_task_role_policy" {

  statement {
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents",
      "logs:GetLogEvents",
      "logs:FilterLogEvents"
    ]
    resources = ["arn:aws:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:*"]
  }

  statement {
    actions = [
      "ec2:Describe*"
    ]
    resources = ["*"]
  }

  statement {
    actions = [
      "ecs:GetTask"
    ]
    resources = [module.ecs.ecs_task_def_arn]
  }
  #arn:aws:ecs:eu-west-1:ACCOUNT_ID:task/ecs-ado-ecs-cluster-dev/
  statement {
    actions = [
      "ecs:DescribeTasks"
    ]
    resources = ["arn:aws:ecs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:task/${local.prefix}-ecs-cluster-${var.environment}/*"]
  }
  statement {
    actions = [
      "iam:PassRole"
    ]
    resources = [
      "${module.iam_ecs_task_exec_role.aws_iam_role_arn}",
      "${module.iam_ecs_task_role.aws_iam_role_arn}"
    ]
  }

}