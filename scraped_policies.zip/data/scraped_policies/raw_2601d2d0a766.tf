data "aws_iam_policy_document" "lambda_start_clip_embed" {
  statement {
    sid = "BedrockAsync"
    actions = [
      "bedrock:StartAsyncInvoke",
      "bedrock:GetAsyncInvoke",
      "bedrock:InvokeModel",
    ]
    resources = concat(
      local.marengo_foundation_arns,
      [
        "arn:aws:bedrock:${var.aws_region}:${data.aws_caller_identity.current.account_id}:async-invoke/*",
      ],
    )
  }

  statement {
    sid       = "S3ReadInputWriteOutput"
    actions   = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"]
    resources = [aws_s3_bucket.videos.arn, "${aws_s3_bucket.videos.arn}/*"]
  }

  statement {
    sid       = "ReadDbSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }
}