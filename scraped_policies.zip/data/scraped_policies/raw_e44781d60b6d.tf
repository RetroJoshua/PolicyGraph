resource "aws_iam_role_policy" "t2s-codedeploy" {
  name   = "t2s-codedeploy-policy"
  role   = aws_iam_role.t2s-codedeploy.id
  policy = data.aws_iam_policy_document.t2s-codedeploy-role-policy.json

    # Add lifecycle configuration to ignore changes to all attributes
  lifecycle {
    ignore_changes = all
  }
}