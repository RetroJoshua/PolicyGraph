resource "aws_iam_policy" "karpenter_policy" {
    name        = format("%s-karpenter", var.cluster_name)
    path        = "/"
    description = var.cluster_name

    policy = data.aws_iam_policy_document.karpenter_policy.json
}