resource "aws_iam_policy" "sample_data" {
#   policy = jsonencode({
#     Version = "2012-10-17"
#     Id      = "${local.prefix}-databricks-sample-data"
#     Statement = [
#       {
#         "Action" : [
#           "s3:GetObject",
#           "s3:GetObjectVersion",
#           "s3:ListBucket",
#           "s3:GetBucketLocation"
#         ],
#         "Resource" : [
#           "arn:aws:s3:::databricks-datasets-oregon/*",
#           "arn:aws:s3:::databricks-datasets-oregon"

#         ],
#         "Effect" : "Allow"
#       }
#     ]
#   })
#   tags = {
#     Name = "${local.prefix} UC policy"
#     Owner = var.resource_owner
#   }
# }