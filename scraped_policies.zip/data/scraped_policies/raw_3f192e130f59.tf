resource "aws_iam_policy" "github_deploy_policy" {
  policy = templatefile("${path.module}/templates/push_to_ecr_policy.json.tpl", {})
  name   = "GithubDeployPianoLessonsPolicy"
}