resource "aws_iam_role" "event_target" {
  name               = "${var.task_family}-event-target"
  assume_role_policy = data.aws_iam_policy_document.principal.json
}