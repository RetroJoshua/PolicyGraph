resource "aws_iam_policy" "unity_metastore" {
#   policy = jsonencode({
#     "Version" : "2012-10-17",
#     "Statement" : [
#       {
#         "Action" : [
#           "s3:GetObject",
#           "s3:GetObjectVersion",
#           "s3:PutObject",
#           "s3:PutObjectAcl",
#           "s3:DeleteObject",
#           "s3:ListBucket",
#           "s3:GetBucketLocation",
#           "s3:GetLifecycleConfiguration",
#           "s3:PutLifecycleConfiguration"
#         ],
#         "Resource" : [
#           aws_s3_bucket.unity_catalog.arn,
#           "${aws_s3_bucket.unity_catalog.arn}/*"
#         ],
#         "Effect" : "Allow"
#       },
#     ]
#   })
#   tags = {
#     Name = "${local.prefix} UC policy"
#     Owner = var.resource_owner
#   }
# }