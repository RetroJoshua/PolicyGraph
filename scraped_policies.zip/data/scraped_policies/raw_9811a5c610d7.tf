resource "aws_iam_role_policy" "snapshots" {
  count = var.aws_snapshots ? 1 : 0

  name   = format(local.name_tmpl, "dlm-snapshots")
  role   = aws_iam_role.snapshots[0].id
  policy = data.aws_iam_policy_document.snapshots[0].json
}