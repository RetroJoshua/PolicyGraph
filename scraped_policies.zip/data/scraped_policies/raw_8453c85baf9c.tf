resource "aws_iam_role" "replication_role" {
  name               = "replication_role"
  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}