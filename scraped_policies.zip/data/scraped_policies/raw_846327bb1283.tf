resource "aws_iam_role" "IAMRole3" {
  path                 = "/service-role/"
  name                 = "CognitoAccessForAmazonES"
  assume_role_policy   = data.aws_iam_policy_document.es_assume_role_policy.json
  max_session_duration = 3600
}