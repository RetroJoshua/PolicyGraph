resource "aws_iam_role" "snapshots" {
  count = var.aws_snapshots ? 1 : 0

  name               = format(local.name_tmpl, "dlm-snapshots")
  assume_role_policy = data.aws_iam_policy_document.snapshots_sts[0].json
}