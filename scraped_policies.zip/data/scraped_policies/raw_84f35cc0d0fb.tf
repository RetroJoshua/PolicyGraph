resource "aws_iam_policy" "logging_policy" {
  name        = "logger-policy"
  description = "Policy for auto-scaler"
  policy      = data.aws_iam_policy_document.logging_policy.json
}