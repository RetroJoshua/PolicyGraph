data "aws_iam_policy_document" "s3Prod_policy" {
  statement {
    sid = "CloudFrontCachingfromPrivateS3"
    actions   = ["s3:GetObject"]
    resources = ["${aws_s3_bucket.S3Prod_bucket.arn}/*"]

    principals {
      type        = "Service"
      identifiers = ["cloudfront.amazonaws.com"]
    }

    condition {
      test = "StringEquals"
      variable = "AWS:SourceArn"
      values = [aws_cloudfront_distribution.s3_distribution.arn]
    }
  }
}