resource "aws_iam_role" "ecr" {
    name               = "${var.service_name}-ECR-ReadForECSServiceAccount"
    assume_role_policy = "${data.aws_iam_policy_document.assume_by_ecr.json}"
}