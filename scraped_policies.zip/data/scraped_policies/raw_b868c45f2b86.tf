data "aws_iam_policy_document" "lambda_finalize_clip_embed" {
  statement {
    sid       = "S3ReadOutput"
    actions   = ["s3:GetObject", "s3:ListBucket"]
    resources = [aws_s3_bucket.videos.arn, "${aws_s3_bucket.videos.arn}/*"]
  }

  statement {
    sid       = "ReadDbSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }

  statement {
    sid       = "RunPegasusTask"
    actions   = ["ecs:RunTask"]
    resources = [replace(aws_ecs_task_definition.clip_pegasus_worker.arn, "/:[0-9]+$/", ":*")]
  }

  statement {
    sid     = "PassPegasusRoles"
    actions = ["iam:PassRole"]
    resources = [
      aws_iam_role.clip_pegasus_worker_task.arn,
      aws_iam_role.clip_pegasus_worker_execution.arn,
    ]
  }
}