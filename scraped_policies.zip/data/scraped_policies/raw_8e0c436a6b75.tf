data "aws_iam_policy" "aws_ssm_default" {
  name = "AmazonSSMManagedInstanceCore"
}