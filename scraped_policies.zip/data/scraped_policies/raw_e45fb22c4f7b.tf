resource "aws_iam_policy" "lambda-additional-policy" {
  name        = "${module.env.module_name}_lambda_access_${var.region_name}_${module.env.stage}"
  description = "additional policy for lambda access"

  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": [
        "lambda:InvokeFunction"
      ],
      "Resource": "${module.hbee.lambda_arn}",
      "Effect": "Allow"
    }
  ]
}
EOF
}