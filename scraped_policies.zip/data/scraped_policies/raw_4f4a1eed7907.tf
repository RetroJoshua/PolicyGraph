data "aws_iam_policy_document" "local_cur" {
  statement {
    sid    = "AllowTLS12Only"
    effect = "Deny"

    principals {
      identifiers = ["*"]
      type        = "AWS"
    }

    actions = ["s3:*"]

    resources = [
      local.local_bucket_arn,
      "${local.local_bucket_arn}/*",
    ]

    condition {
      test     = "NumericLessThan"
      variable = "s3:TlsVersion"
      values   = ["1.2"]
    }
  }

  statement {
    sid     = "RequireHTTPS"
    actions = ["s3:*"]
    effect  = "Deny"

    resources = [
      local.local_bucket_arn,
      "${local.local_bucket_arn}/*",
    ]

    principals {
      identifiers = ["*"]
      type        = "AWS"
    }

    condition {
      test     = "Bool"
      variable = "aws:SecureTransport"
      values   = ["false"]
    }
  }

  statement {
    sid       = "AllowLocalRead"
    effect    = "Allow"
    actions   = ["s3:GetBucketAcl", "s3:GetBucketPolicy"]
    resources = [local.local_bucket_arn]

    principals {
      identifiers = ["billingreports.amazonaws.com"]
      type        = "Service"
    }
  }

  statement {
    sid       = "AllowLocalWrite"
    effect    = "Allow"
    actions   = ["s3:PutObject"]
    resources = ["${local.local_bucket_arn}/*"]

    principals {
      identifiers = ["billingreports.amazonaws.com"]
      type        = "Service"
    }
  }
}