resource "aws_iam_role_policy" "ssm_logs_s3_write" {
#   count    = var.enable_test1_vpc ? 1 : 0
#   provider = aws.test1

#   name   = "allow-ssm-logs-s3-write"
#   role   = aws_iam_role.ssm_client[0].name
#   policy = data.aws_iam_policy_document.ssm_logs_s3_write[0].json
# }