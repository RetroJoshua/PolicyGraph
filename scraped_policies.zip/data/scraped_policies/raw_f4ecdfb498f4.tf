resource "aws_iam_role" "yolo_detect_worker_execution" {
  name               = "${var.project_name}-yolo-detect-execution"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume_role.json
  tags               = local.common_tags
}