resource "aws_iam_role" "terraform_dev_role" {
  name = "${var.prefix}-terraform_dev_role"

  assume_role_policy = data.aws_iam_policy_document.dev_assume_role_policy_definition.json
}