data "aws_iam_policy_document" "lambda_start_frame_task" {
  statement {
    sid       = "RunWorkerTask"
    actions   = ["ecs:RunTask"]
    resources = [replace(aws_ecs_task_definition.frame_embed_worker.arn, "/:[0-9]+$/", ":*")]
  }

  statement {
    sid     = "PassWorkerRoles"
    actions = ["iam:PassRole"]
    resources = [
      aws_iam_role.frame_worker_task.arn,
      aws_iam_role.frame_worker_execution.arn,
    ]
  }
}