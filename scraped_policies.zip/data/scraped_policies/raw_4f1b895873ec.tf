resource "aws_iam_role" "github_deploy_role" {
  assume_role_policy = templatefile("${path.module}/templates/github_assume_role.json.tpl", {})
  name               = "GithubDeployPianoLessonsToECR"
}