resource "aws_iam_role_policy" "yolo_detect_worker_task" {
  name   = "${var.project_name}-yolo-detect-task"
  role   = aws_iam_role.yolo_detect_worker_task.id
  policy = data.aws_iam_policy_document.yolo_detect_worker_task.json
}