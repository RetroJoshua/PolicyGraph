resource "aws_iam_policy" "ec2_read_access_policy" {
  name   = "EC2_read_only"
  policy = file("AmazonEC2ReadOnlyAccess.json")
}