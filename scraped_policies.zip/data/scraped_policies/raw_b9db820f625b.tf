data "aws_iam_policy_document" "lb_access_logs" {
  count = var.alb_access_log_bucket == null ? 1 : 0
  policy_id = "Policy"

  override_json = var.lb_logs_bucket_policy_override

  statement {
    actions = ["s3:PutObject"]
    effect = "Allow"
    resources = [
      aws_s3_bucket.lb_access_logs[0].arn,
      "${aws_s3_bucket.lb_access_logs[0].arn}/*"
    ]
    principals {
      identifiers = [data.aws_elb_service_account.main.arn]
      type = "AWS"
    }
  }
}