resource "aws_iam_role" "rds_enhanced_monitoring" {
  count = local.rds_enhanced_monitoring_enabled_count

  assume_role_policy = data.aws_iam_policy_document.rds_enhanced_monitoring.json
  name               = format("%s-rds-enhanced-monitoring", module.labels.id)
  tags               = module.labels.tags
}