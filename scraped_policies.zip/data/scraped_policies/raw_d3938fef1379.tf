resource "aws_iam_role_policy" "lf_data_access_cloudwatch" {
  count  = var.create_lf_resource && var.create_lf_data_access_role ? 1 : 0
  name   = "cloudwatch_access"
  role   = aws_iam_role.lf_data_access[0].id
  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Sid": "Sid1",
            "Effect": "Allow",
            "Action": [
                "logs:CreateLogStream",
                "logs:CreateLogGroup",
                "logs:PutLogEvents"
            ],
            "Resource": [
                 "arn:aws:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:log-group:/aws-lakeformation-acceleration/*",
                 "arn:aws:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:log-group:/aws-lakeformation-acceleration/*:log-stream:*"
            ]
        }
    ]
}  
EOF
}