data "aws_iam_policy_document" "allow_read_from_public_prod" {
  statement {
    effect = "Allow"

    principals {
      type = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:GetObject"
    ]

    resources = [
      aws_s3_bucket.banodoco_data_bucket.arn,
      "${aws_s3_bucket.banodoco_data_bucket.arn}/*",
    ]
  }

  statement {
    effect = "Allow"

    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.ec2_ssm_access_role.arn]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      aws_s3_bucket.banodoco_data_bucket.arn,
      "${aws_s3_bucket.banodoco_data_bucket.arn}/*",
    ]
  }
  
}