resource "aws_iam_policy" "worker_node_policy" {
  count  = length(local.worker_policies)
  name   = "${local.worker_policies[count.index][0]}_policy"
  policy = file(local.worker_policies[count.index][1])
}