data "aws_iam_policy_document" "frame_worker_task" {
  statement {
    sid       = "BedrockInvokeImage"
    actions   = ["bedrock:InvokeModel"]
    resources = concat(local.marengo_foundation_arns, [local.marengo_inference_profile_arn])
  }

  statement {
    sid       = "S3ReadVideoWriteThumbs"
    actions   = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"]
    resources = [aws_s3_bucket.videos.arn, "${aws_s3_bucket.videos.arn}/*"]
  }

  statement {
    sid       = "ReadDbSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }
}