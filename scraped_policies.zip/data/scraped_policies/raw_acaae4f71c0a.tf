resource "aws_iam_role_policy" "asg_lifecycle" {
  name   = "${var.name_prefix}-asg-lifecycle"
  role   = aws_iam_role.asg_lifecycle.id
  policy = data.aws_iam_policy_document.asg_lifecycle.json
}