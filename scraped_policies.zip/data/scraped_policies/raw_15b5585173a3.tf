resource "aws_iam_role" "clip_pegasus_worker_execution" {
  name               = "${var.project_name}-clip-pegasus-execution"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume_role.json
  tags               = local.common_tags
}