resource "aws_iam_policy" "vod-storage-bucket-access-ro" {
  name = "vod-storage-bucket-ro-${var.env}"
  path = "/buckets/"

  tags = {
    Environment = var.env
  }

  policy = jsonencode(
    {
      Version : "2012-10-17",
      Statement : [
        {
          Sid : "TF1",
          Effect : "Allow",
          Action : [
            "s3:GetLifecycleConfiguration",
            "s3:GetBucketTagging",
            "s3:GetInventoryConfiguration",
            "s3:GetObjectVersionTagging",
            "s3:ListBucketVersions",
            "s3:GetBucketLogging",
            "s3:ListBucket",
            "s3:GetAccelerateConfiguration",
            "s3:GetObjectVersionAttributes",
            "s3:GetBucketPolicy",
            "s3:GetObjectVersionTorrent",
            "s3:GetObjectAcl",
            "s3:GetEncryptionConfiguration",
            "s3:GetBucketObjectLockConfiguration",
            "s3:GetIntelligentTieringConfiguration",
            "s3:GetBucketRequestPayment",
            "s3:GetObjectVersionAcl",
            "s3:GetObjectTagging",
            "s3:GetMetricsConfiguration",
            "s3:GetBucketOwnershipControls",
            "s3:GetBucketPublicAccessBlock",
            "s3:GetBucketPolicyStatus",
            "s3:ListBucketMultipartUploads",
            "s3:GetObjectRetention",
            "s3:GetBucketWebsite",
            "s3:GetObjectAttributes",
            "s3:GetBucketVersioning",
            "s3:GetBucketAcl",
            "s3:GetObjectLegalHold",
            "s3:GetBucketNotification",
            "s3:ListMultipartUploadParts",
            "s3:GetObject",
            "s3:GetObjectTorrent",
            "s3:GetBucketCORS",
            "s3:GetAnalyticsConfiguration",
            "s3:GetObjectVersionForReplication",
            "s3:GetBucketLocation",
            "s3:GetObjectVersion"
          ]
          Resource : [
            "arn:aws:s3:::${aws_s3_bucket.vod-asset-storage-bucket.bucket}/*",
            "arn:aws:s3:::${aws_s3_bucket.vod-asset-storage-bucket.bucket}"
          ]
        }
      ]
  })
}