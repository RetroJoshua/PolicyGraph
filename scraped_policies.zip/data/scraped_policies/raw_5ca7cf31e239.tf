resource "aws_iam_policy" "ecs_deploy" {
  name        = "ecs-deploy"
  path        = "/"
  description = "Execution basics for ECS Deploy"
  policy      = "${var.iam_policy}"
}