resource "aws_iam_policy" "vod-storage-bucket-access-rw" {
  name = "vod-storage-bucket-rw-${var.env}"
  path = "/buckets/"

  tags = {
    Environment = var.env
  }

  policy = jsonencode(
    {
      Version : "2012-10-17",
      Statement : [
        {
          Sid : "TF1",
          Effect : "Allow",
          Action : "s3:*",
          Resource : [
            "arn:aws:s3:::${aws_s3_bucket.vod-asset-storage-bucket.bucket}/*",
            "arn:aws:s3:::${aws_s3_bucket.vod-asset-storage-bucket.bucket}"
          ]
        }
      ]
  })
}