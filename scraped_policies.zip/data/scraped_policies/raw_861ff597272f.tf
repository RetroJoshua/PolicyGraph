data "aws_iam_policy_document" "kms_key_policy" {
  count = try(var.settings.encryption_at_rest.enabled, false) ? 1 : 0
  statement {
    sid    = "AllowAtlasToUseKMS"
    effect = "Allow"
    actions = [
      "kms:Decrypt",
      "kms:DescribeKey",
      "kms:Encrypt",
      "kms:GenerateDataKey",
      "kms:ReEncrypt*",
    ]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = [module.project.cloud_provider_setup_aws_account_arn]
    }
  }
  statement {
    sid    = "RootUserAccess"
    effect = "Allow"
    actions = [
      "kms:*"
    ]
    resources = ["*"]
    principals {
      type        = "AWS"
      identifiers = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"]
    }
  }
}