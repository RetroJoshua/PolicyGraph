data "aws_iam_policy_document" "kinesis_assume" {
  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["logs.${length(var.region) > 0 ? var.region : data.aws_region.default.name}.amazonaws.com"]
    }
  }
}