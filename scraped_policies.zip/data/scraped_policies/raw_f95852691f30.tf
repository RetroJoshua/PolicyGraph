resource "aws_iam_policy" "this" {
  name   = "eks-${data.aws_ssm_parameter.eks_cluster_name.value}-${local.name}"
  policy = local.iam_policy_doc
}