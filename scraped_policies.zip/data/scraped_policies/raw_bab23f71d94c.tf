data "aws_iam_policy_document" "assume_by_ecr" {
   statement {
     sid = ""
     effect = "Allow"
      actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["codebuild.amazonaws.com"]
    }
   }
}