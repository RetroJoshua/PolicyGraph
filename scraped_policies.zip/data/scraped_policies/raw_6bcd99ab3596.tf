resource "aws_iam_role" "log" {
  count              = var.enabled == "true" ? 1 : 0
  name               = module.vpc_label.id
  assume_role_policy = data.aws_iam_policy_document.log_assume.json
}