resource "aws_iam_policy" "ce" {
  name   = "ccf-api-ce-policy"
  policy = data.aws_iam_policy_document.ce.json
}