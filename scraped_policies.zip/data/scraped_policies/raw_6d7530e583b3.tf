resource "aws_iam_role_policy" "bedrock_agent_alert_policy" {
  name = "bedrock-agent-alert-lambda-policy"
  role = aws_iam_role.bedrock_agent_role.id  # Attaches to your existing agent role

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid      = "InvokeAlertLambda"
        Effect   = "Allow"
        Action   = "lambda:InvokeFunction"
        Resource = aws_lambda_function.alert_sender.arn
      }
    ]
  })
}