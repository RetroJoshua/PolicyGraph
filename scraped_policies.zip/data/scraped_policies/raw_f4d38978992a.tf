resource "aws_iam_policy" "lambda_sqs_to_sns" {
  count       = var.send_events_to_sns ? 1 : 0
  name_prefix = "${local.module_name}-lambda-sqs-sns"
  policy      = data.aws_iam_policy_document.lambda_sqs_to_sns[0].json
}