resource "aws_iam_role" "custom_resource_role" {
  count = locals.DelegateDNS ? 1 : 0
  assume_role_policy = {
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = [
            "lambda.amazonaws.com"
          ]
        }
        Action = [
          "sts:AssumeRole"
        ]
      }
    ]
  }
  path = "/"
  force_detach_policies = [
    {
      PolicyName = "DNSandACMAccess"
      PolicyDocument = {
        Version = "2012-10-17"
        Statement = [
          {
            Effect = "Allow"
            Action = [
              "acm:ListCertificates",
              "acm:RequestCertificate",
              "acm:DescribeCertificate",
              "acm:GetCertificate",
              "acm:DeleteCertificate",
              "acm:AddTagsToCertificate",
              "sts:AssumeRole",
              "logs:*",
              "route53:ChangeResourceRecordSets",
              "route53:Get*",
              "route53:Describe*",
              "route53:ListResourceRecordSets",
              "route53:ListHostedZonesByName"
            ]
            Resource = [
              "*"
            ]
          }
        ]
      }
    }
  ]
}