resource "aws_iam_policy" "eks_efs_driver_policy" {
  name        = "xac-efs-csi-driver-policy"
  description = "allow EKS access to EFS"
  policy      = data.aws_iam_policy_document.efs_csi_driver.json
}