resource "aws_iam_policy" "wordpress_bucket_access" {
  name        = "${var.site_name}_WordpressBucketAccess"
  description = "The role that allows Wordpress task to do necessary operations"
  policy      = data.aws_iam_policy_document.wordpress_bucket_access.json
}