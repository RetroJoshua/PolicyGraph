resource "aws_iam_role" "karpenter_role" {
  assume_role_policy = data.aws_iam_policy_document.karpenter_role.json
  name               = format("%s-karpenter", var.cluster_name)
}