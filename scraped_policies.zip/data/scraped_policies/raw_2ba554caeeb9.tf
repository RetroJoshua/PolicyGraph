resource "aws_iam_policy" "fargate-additional-policy" {
  name        = "${module.env.module_name}_fargate_access_${var.region_name}_${module.env.stage}"
  description = "additional policy for fargate access"

  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Action": [
        "ecs:DescribeTasks",
        "ecs:ListTasks"
      ],
      "Resource": "*",
      "Condition" : { "StringEquals" : { "ecs:cluster" : "${aws_ecs_cluster.hcomb_cluster.arn}" }},
      "Effect": "Allow"
    },
    {
      "Action": [
        "ecs:RunTask",
        "ecs:StartTask"
      ],
      "Resource": "${module.hcomb.task_definition_arn}",
      "Effect": "Allow"
    },
    {
      "Action": [
        "iam:PassRole"
      ],
      "Resource": "${aws_iam_role.ecs_task_execution_role.arn}",
      "Effect": "Allow"
    }
  ]
}
EOF
}