resource "aws_iam_policy" "iam_policy" {
    name  = "${local.namespace}-tf-policy"
    policy = data.aws_iam_policy_document.policy_doc.json
}