data "aws_iam_policy_document" "sns_allowall" {
  count = var.sns_allowall && var.enabled ? 1 : 0

  statement {
    actions   = ["sns:*"]
    effect    = "Allow"
    resources = ["*"]
  }
}