data "aws_iam_policy_document" "allow_read_from_public" {
  statement {
    effect = "Allow"

    principals {
      type = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:GetObject"
    ]

    resources = [
      aws_s3_bucket.banodoco_data_bucket_public.arn,
      "${aws_s3_bucket.banodoco_data_bucket_public.arn}/*",
    ]
  }

  statement {
    effect = "Allow"

    principals {
      type        = "AWS"
      identifiers = [aws_iam_role.ec2_ssm_access_role.arn, aws_iam_user.s3_user.arn]
    }

    actions = [
      "s3:*"
    ]

    resources = [
      aws_s3_bucket.banodoco_data_bucket_public.arn,
      "${aws_s3_bucket.banodoco_data_bucket_public.arn}/*",
    ]
  }
  
}