resource "aws_iam_role" "autoscaling_lifecycle" {
#   name               = "${var.name}-autoscaling-lifecycle"
#   assume_role_policy = data.aws_iam_policy_document.autoscaling_trust.json
# }