data "aws_iam_policy_document" "es_access_policy" {
  statement {
    resources = ["arn:aws:es:us-east-1:${data.aws_caller_identity.current.account_id}:domain/sondes-v2*"]
    actions   = ["es:*"]

    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
  }
}