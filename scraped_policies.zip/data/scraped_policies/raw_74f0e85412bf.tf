resource "aws_iam_policy" "s3" {
  name   = "ccf-api-s3-policy"
  policy = data.aws_iam_policy_document.s3.json
}