resource "aws_iam_policy" "sprints_server_management" {
  name   = "server-management-policy"
  policy = data.aws_iam_policy_document.sprints_server_management.json
}