data "aws_iam_policy_document" "sprints_user_management" {
  statement {
    effect = "Allow"
    actions = [
      "iam:CreateUser",
      "iam:DeleteUser",
      "iam:ListUsers",
      "iam:UpdateUser"
    ]
    resources = [
      "arn:aws:iam::${var.account_id}:user/*"
    ]
  }
}