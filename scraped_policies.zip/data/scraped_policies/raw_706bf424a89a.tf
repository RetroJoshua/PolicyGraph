data "aws_iam_policy_document" "passrole_for_uc" {
#   statement {
#     effect  = "Allow"
#     actions = ["sts:AssumeRole"]
#     principals {
#       identifiers = ["arn:aws:iam::ACCOUNT_ID:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"]
#       type        = "AWS"
#     }
#     condition {
#       test     = "StringEquals"
#       variable = "sts:ExternalId"
#       values   = [var.databricks_account_id]
#     }
#   }
#   statement {
#     sid     = "ExplicitSelfRoleAssumption"
#     effect  = "Allow"
#     actions = ["sts:AssumeRole"]
#     principals {
#       type        = "AWS"
#       identifiers = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:root"]
#     }
#     condition {
#       test     = "ArnLike"
#       variable = "aws:PrincipalArn"
#       values   = ["arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/${local.prefix}-unity-catalog"]
#     }
#   }
# }