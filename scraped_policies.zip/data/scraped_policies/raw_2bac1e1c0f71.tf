data "aws_iam_policy_document" "sfn" {
  statement {
    actions = [
      "s3:List*",
      "s3:Get*",
    ]

    resources = [
      aws_s3_bucket.uploads.arn,
      join("", [aws_s3_bucket.uploads.arn, "/*"])
    ]
  }

  statement {
    actions = [
      "lambda:InvokeFunction"
    ]

    resources = [
      aws_lambda_function.validate.arn
    ]
  }

  statement {
    actions = [
      "ecs:RunTask"
    ]

    resources = [
      aws_ecs_task_definition.this.arn
    ]
  }

  statement {
    actions = [
      "ecs:StopTask",
      "ecs:DescribeTasks"
    ]

    resources = [
      "*"
    ]
  }

  statement {
    actions = [
      "iam:PassRole"
    ]

    resources = [
      aws_iam_role.processor.arn
    ]
  }

  statement {
    actions = [
      "events:PutTargets",
      "events:PutRule",
      "events:DescribeRule"
    ]

    resources = [
      join(":", ["arn:aws:events", local.region, local.account_id, "rule/StepFunctionsGetEventsForECSTaskRule"])
    ]
  }
}