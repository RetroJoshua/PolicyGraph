resource "aws_iam_role" "ec2_role" {
  name = "wordpress-app-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })

  tags = {
    Name        = "wordpress-app-role"
    CreatedBy   = "Terraform"
  }
}