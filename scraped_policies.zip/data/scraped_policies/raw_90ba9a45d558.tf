resource "aws_iam_role" "unauth_role" {
  path                 = "/"
  name                 = "Cognito_sondesUnauth_Role"
  assume_role_policy   = data.aws_iam_policy_document.es_unauth_role.json
  max_session_duration = 3600
}