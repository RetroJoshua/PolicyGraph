resource "aws_iam_policy" "datadog_cost_policy" {
  count = var.enable_cur_collection ? 1 : 0

  name        = "DatadogCostPolicy"
  description = "IAM policy for Datadog cloud cost management"
  policy      = data.aws_iam_policy_document.datadog_cost_policy.json
}