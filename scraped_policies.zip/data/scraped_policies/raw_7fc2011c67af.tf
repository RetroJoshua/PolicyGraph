resource "aws_iam_role" "kinesis" {
  count              = var.enabled == "true" ? 1 : 0
  name               = module.kinesis_label.id
  assume_role_policy = data.aws_iam_policy_document.kinesis_assume.json
}