resource "aws_iam_policy" "app_db_pw_secret" {
  name        = "${var.app_name}-db-user-secret"
  description = "Allows retrieval of the app DB user password from Secrets Manager"
  policy      = data.aws_iam_policy_document.app_db_pw_secret.json

  tags = var.db_tags
}