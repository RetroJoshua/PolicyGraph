resource "aws_iam_role_policy" "producer_policy" {
  name = "sqs-producer-policy"
  role = aws_iam_role.producer_role.id
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action   = "sqs:SendMessage"
      Effect   = "Allow"
      Resource = aws_sqs_queue.order_queue.arn
    }]
  })
}