data "aws_iam_policy_document" "ssm_trust" {
#   statement {
#     actions = ["sts:AssumeRole"]
#     principals {
#       type        = "Service"
#       identifiers = ["ssm.amazonaws.com"]
#     }
#   }
# }