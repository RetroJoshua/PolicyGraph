data "aws_iam_policy_document" "asg_lifecycle" {
  statement {
    actions   = ["sns:Publish"]
    resources = [aws_sns_topic.lifecycle.arn]
  }
}