data "aws_iam_policy_document" "clip_pegasus_worker_task" {
  statement {
    sid       = "BedrockInvokePegasus"
    actions   = ["bedrock:InvokeModel", "bedrock:InvokeModelWithResponseStream"]
    resources = concat(local.pegasus_foundation_arns, [local.pegasus_inference_profile_arn])
  }

  statement {
    sid       = "S3ReadVideoWriteCuts"
    actions   = ["s3:GetObject", "s3:PutObject", "s3:ListBucket"]
    resources = [aws_s3_bucket.videos.arn, "${aws_s3_bucket.videos.arn}/*"]
  }

  statement {
    sid       = "ReadDbSecret"
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.db.arn]
  }

  statement {
    sid       = "DescribeSelf"
    actions   = ["sts:GetCallerIdentity"]
    resources = ["*"]
  }
}