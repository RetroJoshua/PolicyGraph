data "aws_iam_policy_document" "master_db_pw_secret" {
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [local.master_db_user_secret_arn]
  }
}