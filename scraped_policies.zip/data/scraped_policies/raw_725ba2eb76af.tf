resource "aws_iam_role_policy" "lbc_extra" {
  name = "${local.name}-lbc-extra"
  role = aws_iam_role.lbc.name

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect   = "Allow"
        Action   = ["ec2:GetSecurityGroupsForVpc"]
        Resource = "*"
      }
    ]
  })
}