resource "aws_iam_policy" "task_role_policy" {
  policy = jsonencode({
    "Version" = "2012-10-17",
    "Statement" = [
      {
        Sid    = "VisualEditor0",
        Effect = "Allow",
        Action = [
          "s3:GetObject",
          "s3:GetAccessPoint",
          "s3:PutAccountPublicAccessBlock",
          "s3:GetAccountPublicAccessBlock",
          "s3:ListAllMyBuckets",
          "s3:ListAccessPoints",
          "s3:ListJobs",
          "s3:CreateJob",
          "s3:PutObject"
        ],
        Resource = "*"
      },
      {
        Sid      = "VisualEditor1",
        Effect   = "Allow",
        Action   = "sts:AssumeRole",
        Resource = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:role/${var.ecs_role_name}"
      },
      {
        Sid    = "VisualEditor2",
        Effect = "Allow",
        Action = "s3:*",
        Resource = [
          module.s3.this_s3_bucket_arn,
          "${module.s3.this_s3_bucket_arn}/*"
        ]
      },
      {
        Sid    = "VisualEditor3",
        Effect = "Allow",
        Action = [
          "SNS:Subscribe",
          "SNS:SetTopicAttributes",
          "SNS:RemovePermission",
          "SNS:Receive",
          "SNS:Publish",
          "SNS:ListSubscriptionsByTopic",
          "SNS:GetTopicAttributes",
          "SNS:DeleteTopic",
          "SNS:AddPermission",
        ],
        Resource = [
          aws_sns_topic.sns_topic.arn,
          "${aws_sns_topic.sns_topic.arn}/*",
        ]
      }
    ]
  })
}