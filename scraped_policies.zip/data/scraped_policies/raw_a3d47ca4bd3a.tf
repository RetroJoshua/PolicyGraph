resource "aws_iam_role_policy" "IAMPolicy3" {
  policy = data.aws_iam_policy_document.auth_cognito_policy.json
  role   = aws_iam_role.auth_role.name
}