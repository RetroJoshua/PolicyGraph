resource "aws_iam_policy" "s3_policy" {
  name        = "s3_policy"
  
  policy = jsonencode({
    Version = "2012-10-17",
    
	"Statement": [
		{
			"Effect": "Allow",
			"Action": [
				"s3:PutObject",
				"s3:ListBucket",
				"s3:GetObject"
			],
			"Resource": ["arn:aws:s3:::shebl-test-2216",
            "arn:aws:s3:::shebl-test-2216/*"
            ]
		}
	]

  })
}