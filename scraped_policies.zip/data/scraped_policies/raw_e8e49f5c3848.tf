resource "aws_iam_role" "frame_worker_execution" {
  name               = "${var.project_name}-frame-worker-execution"
  assume_role_policy = data.aws_iam_policy_document.ecs_tasks_assume_role.json
  tags               = local.common_tags
}