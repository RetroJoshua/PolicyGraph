data "aws_iam_policy_document" "allow_ses_to_write_s3" {

  # Allow ses to write into s3 bucket
  statement {
    sid = "AllowSESToWriteIntoReportsBucket"
    principals {
      type = "Service"
      identifiers = [
        "ses.amazonaws.com"
      ]
    }
    actions = [
      "s3:PutObject"
    ]
    resources = [
      "arn:aws:s3:::${aws_s3_bucket.reports.id}/emails/*"
    ]
    condition {
      test     = "StringEquals"
      variable = "aws:Referer"
      values = [ "${data.aws_caller_identity.current.account_id}" ]
    }
  }
}