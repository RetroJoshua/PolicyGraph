resource "aws_iam_role" "vector_kinesis_writer" {
  name               = "vector-kinesis-writer"
  assume_role_policy = data.aws_iam_policy_document.vector_irsa_assume_role.json
}