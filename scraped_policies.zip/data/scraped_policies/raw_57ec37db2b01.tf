data "aws_iam_policy_document" "unauth_cognito_policy" {
  statement {
    resources = ["*"]

    actions = [
      "mobileanalytics:PutEvents",
      "cognito-sync:*",
    ]
  }
}