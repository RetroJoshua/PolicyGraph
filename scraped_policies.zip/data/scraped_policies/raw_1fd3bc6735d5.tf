data "aws_iam_policy_document" "complete_lifecycle" {
#   statement {
#     actions   = ["autoscaling:CompleteLifecyleAction"]
#     resources = [aws_autoscaling_group.this.arn]
#   }
# }