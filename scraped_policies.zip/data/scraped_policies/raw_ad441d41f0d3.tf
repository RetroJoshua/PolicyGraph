resource "aws_iam_role" "lambda_start_frame_task" {
  name               = "${var.project_name}-start-frame-task"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
  tags               = local.common_tags
}