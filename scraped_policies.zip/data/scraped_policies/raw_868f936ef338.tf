resource "aws_iam_role" "lbc" {
  name               = "${local.name}-lbc"
  assume_role_policy = data.aws_iam_policy_document.lbc_irsa.json

  tags = local.tags
}