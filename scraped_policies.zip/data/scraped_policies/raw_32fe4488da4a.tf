resource "aws_iam_policy" "efs_controller_policy" {
  name_prefix = "efs-csi-driver-policy"
  policy      = data.aws_iam_policy_document.efs_controller_policy_doc.json
}