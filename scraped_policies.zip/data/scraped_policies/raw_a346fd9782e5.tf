data "aws_iam_policy_document" "allow_access_from_another_account" {
  statement {
    principals {
      type        = "AWS"
      identifiers = [var.account_id]  # Replace with real account ID
    }

    actions = [
      "s3:GetObject",
      "s3:ListBucket",
    ]

    resources = [
      aws_s3_bucket.mys3bucket.arn,
      "${aws_s3_bucket.mys3bucket.arn}/*",
    ]
  }
}