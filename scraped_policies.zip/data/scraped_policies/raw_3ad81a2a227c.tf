resource "aws_iam_role" "replication" {
  provider           = aws.primary
  name               = format("sales-s3-replication")
  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}