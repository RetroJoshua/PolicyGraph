resource "aws_iam_role" "albc" {
  count = var.irsa_alb_enabled ? 1 : 0
  name  = join("-", ["irsa", local.clustername, "aws-load-balancer-controller"])
  path  = "/"
  tags  = merge(local.default-tags)
  assume_role_policy = jsonencode({
    Statement = [{
      Action = "sts:AssumeRoleWithWebIdentity"
      Effect = "Allow"
      Principal = {
        Federated = local.oidc["arn"]
      }
      Condition = {
        StringEquals = {
          format("%s:sub", local.oidc["url"]) = local.oidc_fully_qualified_subjects
        }
      }
    }]
    Version = "2012-10-17"
  })
}