data "aws_iam_policy_document" "lambda_create_task_role_policy" {

  statement {
    actions = [
      "logs:CreateLogGroup",
      "logs:CreateLogStream",
      "logs:PutLogEvents"
    ]
    resources = ["arn:aws:logs:${data.aws_region.current.name}:${data.aws_caller_identity.current.account_id}:*"]
  }

  statement {
    actions = [
      "ec2:Describe*"
    ]
    resources = ["*"]
  }

  statement {
    actions = [
      "ecs:RunTask"
    ]
    resources = [module.ecs.ecs_task_def_arn]
  }

  statement {
    actions = [
      "iam:PassRole"
    ]
    resources = [
      "${module.iam_ecs_task_exec_role.aws_iam_role_arn}",
      "${module.iam_ecs_task_role.aws_iam_role_arn}"
    ]
  }

  statement {
    actions = [
      "lambda:InvokeFunction"
    ]
    resources = [
      "${module.get_task_lambda.lambda_function_arn}",
    ]
  }
}