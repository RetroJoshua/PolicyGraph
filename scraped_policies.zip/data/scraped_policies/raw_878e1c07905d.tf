resource "aws_iam_role_policy" "IAMPolicy2" {
  policy = data.aws_iam_policy_document.unauth_cognito_policy.json
  role   = aws_iam_role.unauth_role.name
}