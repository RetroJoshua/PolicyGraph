data "aws_iam_policy_document" "stg-statics-acl" {
  statement {
    effect = "Allow"
    principals {
      type        = "AWS"
      identifiers = ["*"]
    }
    actions = [
        "s3:GetObject",
    ]
    resources = [
      "arn:aws:s3:::stg-static.matsuhub.link",
      "arn:aws:s3:::stg-static.matsuhub.link/*"
    ]
  }
}