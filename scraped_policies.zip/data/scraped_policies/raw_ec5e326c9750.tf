resource "aws_iam_policy" "ecr_policy" {
  count       = var.ecr_pullthrough_cache_rule_config.enable ? 1 : 0
  name        = "ecr_pullthrough_policy-${random_string.policy_suffix[0].result}"
  description = "Policy to enable EKS nodes to create ECR pull-through repositories"
  policy      = data.aws_iam_policy_document.eks_node_custom_inline_policy[0].json
  tags        = var.tags
}