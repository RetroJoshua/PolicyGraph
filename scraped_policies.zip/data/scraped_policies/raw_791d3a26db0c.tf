resource "aws_iam_role" "sso_sagemaker_execution_role" {
  count = var.enable_sso ? 1 : 0
  name  = "${var.domain_name}-sso-sagemaker-execution-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = "sagemaker.amazonaws.com"
        }
        Action = "sts:AssumeRole"
      }
      # NOTE: The SAML provider trust relationship is commented out as it requires
      # manual creation of the SAML provider in IAM. When using AWS IAM Identity Center,
      # the SAML provider is managed by the service and not needed here.
      # If using standalone Okta SAML (without IAM Identity Center), uncomment this:
      # {
      #   Effect = "Allow"
      #   Principal = {
      #     Federated = "arn:aws:iam::${data.aws_caller_identity.current.account_id}:saml-provider/OktaSAML"
      #   }
      #   Action = "sts:AssumeRoleWithSAML"
      #   Condition = {
      #     StringEquals = {
      #       "SAML:aud" = "URL_REDACTED"
      #     }
      #   }
      # }
    ]
  })

  tags = {
    Name = "${var.domain_name}-sso-execution-role"
  }
}