data "aws_iam_policy_document" "lambda_sqs_to_sns" {
  count = var.send_events_to_sns ? 1 : 0
  statement {
    effect = "Allow"
    actions = [
      "sqs:ReceiveMessage",
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes"
    ]
    resources = [aws_sqs_queue.ec2_events.arn]
  }
  statement {
    effect = "Allow"
    actions = [
      "sns:Publish"
    ]
    resources = [aws_sns_topic.mail_notification[0].arn]
  }
}