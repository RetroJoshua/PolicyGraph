resource "aws_iam_role" "dms-access-for-endpoint" {
  assume_role_policy = data.aws_iam_policy_document.dms_assume_role.json
  name               = "${var.dms_instance_name}-dms-access-for-endpoint"
}