data "aws_iam_policy_document" "iam_admin_perm_boundary" {
  version = "2012-10-17"

  statement {
    sid       = "AllowAllActions"
    effect    = "Allow"
    actions   = ["*"]
    resources = ["*"]
  }

  statement {
    sid       = "DenyActionsOnSpecificPermissionSet"
    effect    = "Deny"
    actions   = ["*"]
    resources = [aws_ssoadmin_permission_set.identity_center_admin.arn]
  }
}