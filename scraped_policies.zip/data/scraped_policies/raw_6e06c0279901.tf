data "aws_iam_policy_document" "s3_bucket_policy" {
  statement {
    sid = "AccessForVectorAgentRole"
    principals {
      type        = "AWS"
      identifiers = [module.vector_agent_role.arn]
    }
    actions   = ["s3:ListBucket", "s3:PutObject"]
    resources = ["arn:aws:s3:::${local.bucket_name}", "arn:aws:s3:::${local.bucket_name}/*"]
  }
  statement {
    sid = "AccessForVectorAggregatorRole"
    principals {
      type        = "AWS"
      identifiers = [module.vector_aggregator_role.arn]
    }
    actions   = ["s3:GetObject"]
    resources = ["arn:aws:s3:::${local.bucket_name}/*"]
  }
}