resource "aws_iam_role" "mediapackage" {
  name = "mediapackage-${var.env}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Sid    = ""
        Principal = {
          Service = "mediapackage.amazonaws.com"
        }
      },
    ]
  })
}