data "aws_iam_policy_document" "datadog_cost_policy" {
  statement {
    sid       = "DatadogCostReadBucket"
    actions   = ["s3:ListBucket"]
    effect    = "Allow"
    resources = [local.local_bucket_arn]
  }

  statement {
    sid       = "DatadogCostGetBill"
    actions   = ["s3:GetObject"]
    effect    = "Allow"
    resources = ["${local.local_bucket_arn}/${local.account_id}/*"]
  }

  statement {
    sid = "DatadogCostCheckAccuracy"
    #trivy:ignore:avd-aws-0057
    actions = ["ce:Get*"]
    effect  = "Allow"
    #trivy:ignore:avd-aws-0057
    resources = ["*"]
  }

  statement {
    sid     = "DatadogCostListCURs"
    actions = ["cur:DescribeReportDefinitions"]
    effect  = "Allow"
    #trivy:ignore:avd-aws-0057
    resources = ["*"]
  }

  statement {
    sid    = "DatadogCostListOrganizations"
    effect = "Allow"
    #trivy:ignore:avd-aws-0057
    resources = ["*"]
    #trivy:ignore:avd-aws-0057
    actions = [
      "organizations:Describe*",
      "organizations:List*"
    ]
  }
}