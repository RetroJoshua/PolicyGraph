resource "aws_iam_role_policy" "IAMPolicy4" {
  policy = data.aws_iam_policy_document.flight_doc_cognito.json
  role   = aws_iam_role.auth_role.name
}