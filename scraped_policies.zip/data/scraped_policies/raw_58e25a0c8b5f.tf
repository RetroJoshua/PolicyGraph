resource "aws_iam_role" "codepipeline_role" {
  name               = "${var.name_prefix}-codepipeline-role"
  description        = "The IAM role used by the pipeline"
  assume_role_policy = data.aws_iam_policy_document.codepipeline_assume_role_policy.json
}