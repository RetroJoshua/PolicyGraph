resource "aws_iam_policy" "backup_put_objects" {
  count  = var.create_backup_bucket ? 1 : 0
  path   = "/"
  policy = data.aws_iam_policy_document.backup_put_objects[0].json
  tags   = local.common_tags
}