resource "aws_iam_role_policy" "lambda_start_yolo_task" {
  name   = "${var.project_name}-start-yolo-task"
  role   = aws_iam_role.lambda_start_yolo_task.id
  policy = data.aws_iam_policy_document.lambda_start_yolo_task.json
}