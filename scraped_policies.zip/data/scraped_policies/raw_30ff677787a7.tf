resource "aws_iam_policy" "external_location" {
#   policy = jsonencode({
#     "Version" : "2012-10-17",
#     "Statement" : [
#       {
#         "Action" : [
#           "s3:GetObject",
#           "s3:GetObjectVersion",
#           "s3:PutObject",
#           "s3:PutObjectAcl",
#           "s3:DeleteObject",
#           "s3:ListBucket",
#           "s3:GetBucketLocation",
#           "s3:GetLifecycleConfiguration",
#           "s3:PutLifecycleConfiguration"
#         ],
#         "Resource" : [
#           aws_s3_bucket.cross_region_bucket.arn,
#           "${aws_s3_bucket.cross_region_bucket.arn}/*"
#         ],
#         "Effect" : "Allow"
#       },
#     ]
#   })
#   tags = {
#     Name = "${local.prefix} external location policy"
#     Owner = var.resource_owner
#   }
# }