resource "aws_iam_policy" "cloudtrail_rw" {
  name        = "CloudtrailReadWrite"
  description = "Allow read and write access to our main CloudTrail bucket."
  policy      = data.aws_iam_policy_document.cloudtrail_rw.json
}