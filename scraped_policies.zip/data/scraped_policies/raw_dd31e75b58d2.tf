data "aws_iam_policy_document" "hello_world_sqs_policy_document" {
  statement {
    sid     = "SQSPolicyDocumentId"
    actions = [
      "sqs:ReceiveMessage",
      "sqs:SendMessage",
      "sqs:DeleteMessage",
      "sqs:GetQueueAttributes"
    ]
    resources = [
      aws_sqs_queue.hello_world_queue.arn
    ]
  }
}