resource "aws_iam_role" "lambda_start_clip_embed" {
  name               = "${var.project_name}-start-clip-embed"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
  tags               = local.common_tags
}