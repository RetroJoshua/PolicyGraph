resource "aws_iam_policy" "admin_policy" {
  name = "${local.cluster_name}-k8sAdmins-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action   = "iam:PassRole"
        Effect   = "Allow"
        Resource = "*"
        Condition = {
          StringEquals = {
            "iam:PassedToService" = "eks.amazonaws.com"
          }
        }
      },
      {
        Effect = "Allow",
        Action = [
          "eks:*",
        ],
        Resource = "*"
      }
    ]
  })
}