resource "aws_iam_policy" "automq_byoc_k8s_policy" {
  name        = "automq-byoc-service-k8s-policy-${var.automq_byoc_env_id}"
  description = "Custom policy for automq_byoc service"

  policy = templatefile("${path.module}/tpls/automq_byoc_role_k8s_policy.json.tpl", {
    automq_data_bucket = local.automq_data_bucket
    automq_ops_bucket  = local.automq_ops_bucket
  })

  tags = local.common_tags
}