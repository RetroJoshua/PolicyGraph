resource "aws_iam_role" "ec2_read_access_role" {
  name               = "EC2_RO_role"
  assume_role_policy = file("AssumeRolePolicy.json")

}