resource "aws_iam_role" "ecs_agent_role" {
  name               = "ecs-agent"
  assume_role_policy = data.aws_iam_policy_document.ecs_agent.json
}