data "aws_iam_policy_document" "allow_access_from_same_account" {
  statement {
    principals {
      type        = "AWS"
      identifiers = ["ACCOUNT_ID"]
    }

    actions = [
      "s3:*",
    ]

    resources = [
      aws_s3_bucket.s3_private_log.arn,
      "${aws_s3_bucket.s3_private_log.arn}/*",
    ]
  }
}