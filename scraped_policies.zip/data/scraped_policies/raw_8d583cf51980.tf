resource "aws_iam_policy" "glue" {
  name   = "ccf-api-glue-policy"
  policy = data.aws_iam_policy_document.glue.json
}