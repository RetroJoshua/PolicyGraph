resource "aws_iam_role_policy" "kinesis" {
  count  = var.enabled == "true" ? 1 : 0
  name   = module.vpc_label.id
  role   = aws_iam_role.kinesis.id
  policy = data.aws_iam_policy_document.kinesis.json
}