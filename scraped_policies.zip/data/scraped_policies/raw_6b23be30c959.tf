data "aws_iam_policy_document" "s3" {
  statement {
    actions   = ["s3:*"]
    effect    = "Allow"
    resources = [data.aws_s3_bucket.billing_data_bucket.arn, "${data.aws_s3_bucket.billing_data_bucket.arn}/*"]
  }
  statement {
    actions   = ["s3:*"]
    effect    = "Allow"
    resources = [data.aws_s3_bucket.athena_query_results_bucket.arn, "${data.aws_s3_bucket.athena_query_results_bucket.arn}/*"]
  }
}