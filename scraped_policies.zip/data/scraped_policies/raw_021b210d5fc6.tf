resource "aws_iam_role" "storage_credentials" {
#   name                = "${local.prefix}-${var.peered_vpc_region}"
#   assume_role_policy  = data.aws_iam_policy_document.storage_creds.json
#   managed_policy_arns = [aws_iam_policy.external_location.arn]
#   tags = {
#     Name = "${local.prefix} external location policy"
#     Owner = var.resource_owner
#   }
#   depends_on = [ databricks_metastore_assignment.unity_catalog ]
# }