resource "aws_iam_role" "codebuild_role" {
  count = "${var.ci_container_name != "" ? 1 : 0}"

  name = "tf-${var.name}-codebuild-role"
  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Principal": {
        "Service": "codebuild.amazonaws.com"
      },
      "Action": "sts:AssumeRole"
    }
  ]
}
EOF
}