resource "aws_iam_policy" "sns_publish" {
  name        = "${var.vpc_name}-sns-publish-policy"
  description = "Policy for EC2 to publish messages to SNS"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "sns:Publish"
        ]
        Resource = aws_sns_topic.user_verification.arn
      }
    ]
  })
}