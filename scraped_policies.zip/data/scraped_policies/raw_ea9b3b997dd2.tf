resource "aws_iam_policy" "kinesis_analytics_execution_role" {
  name = "KinesisAnalyticsExecutionRole"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Action   = ["kinesis:*", "lambda:*"]
      Effect   = "Allow"
      Resource = [aws_lambda_function.this.arn, aws_kinesis_stream.this.arn]
    }]
  })
}