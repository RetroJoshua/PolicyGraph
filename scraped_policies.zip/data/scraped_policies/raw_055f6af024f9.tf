resource "aws_iam_role" "db_backup" {
  name               = "db_backup"
  assume_role_policy = data.aws_iam_policy_document.db_backup.json

  
  inline_policy {
    name = "allow_backup"
    policy = data.aws_iam_policy_document.allow_backup.json
  }
}