data "aws_iam_policy_document" "oai_static_data_policy" {
  statement {
    actions = ["s3:GetObject"]
    principals {
      type        = "AWS"
      identifiers = ["${aws_cloudfront_origin_access_identity.oai_static_data.iam_arn}"]
    }
    resources = ["${aws_s3_bucket.static-data-bkt.arn}/*"]
  }
}