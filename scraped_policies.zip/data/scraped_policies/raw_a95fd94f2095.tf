data "aws_iam_policy_document" "es_access" {
  statement {
    resources = ["arn:aws:es:us-east-1:${data.aws_caller_identity.current.account_id}:domain/sondes-*"]
    actions   = ["es:*"]
  }

  statement {
    resources = ["arn:aws:es:us-east-1:${data.aws_caller_identity.current.account_id}:domain/sondes-*"]
    actions   = ["es:*"]
  }
}