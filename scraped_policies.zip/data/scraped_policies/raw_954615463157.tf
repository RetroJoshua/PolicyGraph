resource "aws_iam_role" "db_monitoring" {
  name               = var.db_tags.Name
  assume_role_policy = data.aws_iam_policy_document.db_monitoring_assume_role_policy.json

  tags = var.db_tags
}