resource "aws_iam_role" "sdc-ssm-role" {
  name        = "${var.env}-${var.instance_name}-sdc-ssm-role"
  path        = "/"
  description = "AWS IAM Role required for SSM managed access to the SEC"
  tags = merge(var.tags, {
    Name : "${var.env}-sdc-ssm-role"
  })

  assume_role_policy = data.aws_iam_policy_document.assume_role.json
}