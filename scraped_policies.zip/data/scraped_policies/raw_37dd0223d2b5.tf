resource "aws_iam_policy" "hello_world_sqs_policy" {
  name   = "SQSPolicy"
  policy = data.aws_iam_policy_document.hello_world_sqs_policy_document.json
}