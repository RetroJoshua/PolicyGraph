resource "aws_iam_policy" "s3_policy" {
  name = "s3_policy"
  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Action = [
          "s3:ListBucket",
          "s3:GetObject",
          "s3:PutObject"
        ],
        Effect = "Allow",
        Resource = [
          "arn:aws:s3:::depi-qal-project-s3",
          "arn:aws:s3:::depi-qal-project-s3/*"
        ]
      }
    ]
  })
}