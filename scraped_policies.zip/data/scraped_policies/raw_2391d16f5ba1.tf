data "aws_iam_policy_document" "nas_ses_policy" {
  statement {
    actions   = ["ses:SendRawEmail"]
    resources = [aws_ses_domain_identity.nas.arn]
  }
}