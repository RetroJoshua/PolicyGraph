resource "aws_iam_role_policy" "ec2_complete_lifecycle" {
#   name   = "complete-lifecycle"
#   role   = module.ec2_role.role.name
#   policy = data.aws_iam_policy_document.complete_lifecycle.json
# }