data "aws_iam_policy_document" "eks_node_custom_inline_policy" {
  count = var.ecr_pullthrough_cache_rule_config.enable ? 1 : 0
  statement {
    actions = [
      "ecr:CreateRepository",
      "ecr:ReplicateImage",
      "ecr:BatchImportUpstreamImage"
    ]

    resources = ["*"]
  }
}