data "aws_iam_policy_document" "media" {
  statement {
    actions = ["s3:GetObject"]
    resources = [
      "arn:aws:s3:::${var.s3_media_bucket_name}",
      "arn:aws:s3:::${var.s3_media_bucket_name}/*"
    ]

    principals {
      type        = "AWS"
      identifiers = [aws_cloudfront_origin_access_identity.origin_access_identity_media.iam_arn]
    }
  }
}