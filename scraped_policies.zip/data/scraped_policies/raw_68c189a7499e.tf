resource "aws_iam_role_policy" "flow_log_cw" {
  count = var.enabled && local.log_cloudwatch_creation_enabled ? 1 : 0

  name   = "${module.label.id}-cw"
  role   = aws_iam_role.cloudwatch[0].id
  policy = data.aws_iam_policy_document.flow_log_cw[0].json
}