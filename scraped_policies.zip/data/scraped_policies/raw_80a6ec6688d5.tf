resource "aws_iam_role" "cloudfront_example" {
  name               = "cloudfront-realtime-log-config-role"
  assume_role_policy = data.aws_iam_policy_document.cloudfront_assume_role.json
}