resource "aws_iam_policy" "ca_iam_policy" {
  name        = "ca_iam_policy-${var.infra_name}"
  description = "ca policy"
  policy      = file("${path.module}/policy/ca_iam_policy.json")
  depends_on = [ aws_iam_openid_connect_provider.oidc_provider ]
}