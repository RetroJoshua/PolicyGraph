data "aws_iam_policy_document" "ads_domain_join" {
  count = var.ads_domain_join && var.enabled ? 1 : 0

  statement {
    effect    = "Allow"
    resources = ["*"]

    actions = [
      "ds:CreateComputer",
      "ds:DescribeDirectories"
    ]
  }
}