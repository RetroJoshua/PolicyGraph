data "aws_iam_policy" "ssm" {
  name = "AmazonSSMManagedInstanceCore"
}