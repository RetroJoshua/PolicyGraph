resource "aws_iam_role" "cloudformation_execution_role" {
  name = "${local.stack_name}-CFNExecutionRole"
  assume_role_policy = {
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Principal = {
          Service = [
            "cloudformation.amazonaws.com",
            "lambda.amazonaws.com"
          ]
        }
        Action = "sts:AssumeRole"
      }
    ]
  }
  path = "/"
  force_detach_policies = [
    {
      PolicyName = "executeCfn"
      PolicyDocument = {
        Version = "2012-10-17"
        Statement = [
          {
            Effect = "Allow"
            NotAction = [
              "organizations:*",
              "account:*"
            ]
            Resource = "*"
          },
          {
            Effect = "Allow"
            Action = [
              "organizations:DescribeOrganization",
              "account:ListRegions"
            ]
            Resource = "*"
          }
        ]
      }
    }
  ]
}