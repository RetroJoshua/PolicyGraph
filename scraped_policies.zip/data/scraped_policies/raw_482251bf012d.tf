resource "aws_iam_role_policy" "frame_worker_task" {
  name   = "${var.project_name}-frame-worker-task"
  role   = aws_iam_role.frame_worker_task.id
  policy = data.aws_iam_policy_document.frame_worker_task.json
}