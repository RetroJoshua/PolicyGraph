resource "aws_iam_role" "sample_vm_instance_role" {
  count              = var.enable_sample_vm ? 1 : 0
  name               = "sample-vm-instance-role"
  description        = "A role used to access CAST AI nodes via SSM"
  assume_role_policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": {
    "Effect": "Allow",
    "Principal": {
      "Service": "ec2.amazonaws.com"
    },
    "Action": ["sts:AssumeRole","sts:TagSession"]
  }
}
EOF
  tags = {
    Name = local.vm_name
    "env" : var.environment
  }
}