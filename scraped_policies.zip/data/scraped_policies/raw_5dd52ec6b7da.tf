resource "aws_iam_policy" "albc" {
  count       = var.irsa_alb_enabled ? 1 : 0
  name        = join("-", ["irsa", local.clustername, "aws-load-balancer-controller"])
  description = format("Allow aws-load-balancer-controller to manage AWS resources")
  path        = "/"
  policy      = file("${path.module}/templates/alb_policy.json")
}