resource "aws_iam_policy" "jenkins_policy" {
  name   = "jenkins-policy"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow"
        Action = [
          "ecr:GetAuthorizationToken",
          "ecr:BatchCheckLayerAvailability",
          "ecr:CompleteLayerUpload",
          "ecr:UploadLayerPart",
          "ecr:PutImage",
          "ecr:InitiateLayerUpload", 
          "ec2:*",  # Full access to all EC2 actions (for logging in and interacting with EC2)
          "iam:PassRole"  # Necessary to allow Jenkins to pass IAM roles to EC2 instances
        ]
        Resource = "*"
      }
    ]
  })
}