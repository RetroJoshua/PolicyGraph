resource "aws_iam_policy" "mediapackage-passrole" {
  name = "mediapackage-passrole-${var.env}"
  path = "/mediapackage/"

  tags = {
    Environment = var.env
  }

  policy = jsonencode(
    {
      "Version" : "2012-10-17",
      "Statement" : [{
        "Effect" : "Allow",
        "Action" : [
          "iam:GetRole",
          "iam:PassRole"
        ],
        "Resource" : aws_iam_role.mediapackage.arn
      }]
    }
  )
}