resource "aws_iam_policy" "sprints_user_management" {
  name   = "user-management-policy"
  policy = data.aws_iam_policy_document.sprints_user_management.json
}