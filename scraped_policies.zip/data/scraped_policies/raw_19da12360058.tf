resource "aws_iam_role" "ec2_ssm_role" {
  name = "EC2SSMRole"

  # Define the trust policy allowing EC2 instances to assume this role
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = {
        Service = "ec2.amazonaws.com" # Only EC2 instances can assume this role
      }
      Action = "sts:AssumeRole" # Allows EC2 instances to request temporary credentials
    }]
  })
}