resource "aws_iam_policy" "athena" {
  name   = "ccf-api-athena-policy"
  policy = data.aws_iam_policy_document.athena.json
}