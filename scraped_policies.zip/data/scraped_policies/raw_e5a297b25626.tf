resource "aws_iam_policy" "sprints_database_management" {
  name   = "database-management-policy"
  policy = data.aws_iam_policy_document.sprints_database_management.json
}