data "aws_iam_policy_document" "flow_log_cw_assume" {
  count = var.enabled && local.log_cloudwatch_creation_enabled ? 1 : 0

  statement {
    actions = ["sts:AssumeRole"]

    principals {
      type        = "Service"
      identifiers = ["vpc-flow-logs.amazonaws.com"]
    }
  }
}