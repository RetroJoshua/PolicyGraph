resource "aws_iam_policy" "delete_me_now_please" {
  provider = aws.test1

  name   = "DeleteMePleaseNow"
  policy = data.aws_iam_policy_document.test_ec2_actions.json
}