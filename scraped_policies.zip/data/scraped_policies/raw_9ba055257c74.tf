resource "aws_iam_role_policy" "lf_data_access_s3" {
  count  = var.create_lf_resource && var.create_lf_data_access_role ? 1 : 0
  name   = "s3_access"
  role   = aws_iam_role.lf_data_access[0].id
  policy = <<EOF
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": [
                "s3:PutObject",
                "s3:GetObject",
                "s3:DeleteObject"
            ],
            "Resource": [
                "arn:aws:s3:::${local.apiary_bucket_prefix}-*/*"
            ]
        },
        {
            "Effect": "Allow",
            "Action": [
                "s3:ListBucket"
            ],
            "Resource": [
                "arn:aws:s3:::${local.apiary_bucket_prefix}-*"
            ]
        }
    ]
}
EOF
}