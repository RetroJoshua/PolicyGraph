resource "aws_iam_role_policy" "cloudfront_example" {
  name   = "cloudfront-realtime-log-config-policy"
  role   = aws_iam_role.cloudfront_example.id
  policy = data.aws_iam_policy_document.cloudfront_example.json
}