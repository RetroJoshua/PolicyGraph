resource "aws_iam_policy" "stream_raw_to_s3" {
  description = null
  name        = "FireHoseS3StreamRawToS3Policy"
  name_prefix = null
  path        = "/"
  policy = jsonencode({
    Statement = [{
      Action   = ["kinesis:GetRecords", "kinesis:GetShardIterator", "kinesis:DescribeStream", "kinesis:ListShards"]
      Effect   = "Allow"
      Resource = aws_kinesis_stream.this.arn
      Sid      = "KinesisReadAccess"
      }, {
      Action   = ["s3:AbortMultipartUpload", "s3:GetBucketLocation", "s3:GetObject", "s3:ListBucket", "s3:ListBucketMultipartUploads", "s3:PutObject"]
      Effect   = "Allow"
      Resource = [aws_s3_bucket.stream_raw_to_s3.arn, "${aws_s3_bucket.stream_raw_to_s3.arn}/*"]
      Sid      = "S3WriteAccess"
    }]
    Version = "2012-10-17"
  })
  tags     = {}
  tags_all = {}

  depends_on = [aws_kinesis_stream.this, aws_iam_role.stream_raw_to_s3, aws_s3_bucket.stream_raw_to_s3]
}