resource "aws_iam_policy" "replication" {
  provider = aws.primary
  name     = format("sales-s3-replication")
  policy   = data.aws_iam_policy_document.replication.json
}