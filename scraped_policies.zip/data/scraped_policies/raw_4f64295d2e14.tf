data "aws_iam_policy_document" "karpenter_policy" {
    version = "2012-10-17"

    statement {

        effect  = "Allow"
        actions = [
            "ec2:CreateLaunchTemplate",
            "ec2:CreateFleet",
            "ec2:CreateTags",
            "ec2:DescribeLaunchTemplates",
            "ec2:DescribeInstances",
            "ec2:DescribeSecurityGroups",
            "ec2:DescribeSubnets",
            "ec2:DescribeInstanceTypes",
            "ec2:DescribeInstanceTypeOfferings",
            "ec2:DescribeAvailabilityZones",
            "ec2:DescribeSpotPriceHistory",
            "ec2:DescribeImages",
            "pricing:GetProducts",
            "ec2:RunInstances",
            "ssm:GetParameter",
            "iam:PassRole",
            "iam:GetInstanceProfile",
            "iam:CreateInstanceProfile",
            "iam:TagInstanceProfile",
            "iam:AddRoleToInstanceProfile",
            "iam:DeleteInstanceProfile",
            "autoscaling:CompleteLifecycleAction",
            "autoscaling:DescribeAutoScalingInstances",
            "autoscaling:DescribeTags",
            "ec2:DescribeInstances",
            "sqs:DeleteMessage",
            "sqs:ReceiveMessage",
            "sqs:GetQueueAttributes",
            "sqs:GetQueueUrl",            
            "eks:DescribeCluster"           
        ]

        resources = [ 
          "*"
        ]

    }

    statement {

        effect  = "Allow"
        actions = [
            "ec2:TerminateInstances",
            "ec2:DeleteLaunchTemplate",  
        ]

        resources = [ 
          "*"
        ]

    }
    
}