resource "aws_iam_role" "api_gateway_logging" {
  name               = "api_gateway_logging_role"
  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect = "Allow"
      Principal = { Service = "apigateway.amazonaws.com" }
      Action = "sts:AssumeRole"
    }]
  })

  lifecycle {
    prevent_destroy = false  
  }
}