resource "aws_iam_role_policy" "sqs_policy" {
  for_each = {
    for name, handler in var.handlers : name => handler.sqs
    if handler.sqs != null
  }

  name = "sqs-permissions-${each.key}"
  role = split("/", aws_lambda_function.handlers[each.key].role)[1]

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "SQSPermissions"
        Effect = "Allow"
        Action = [
          "sqs:ReceiveMessage",
          "sqs:DeleteMessage",
          "sqs:GetQueueAttributes",
          "sqs:ChangeMessageVisibility"
        ]
        Resource = [each.value.queue]
      }
    ]
  })
}