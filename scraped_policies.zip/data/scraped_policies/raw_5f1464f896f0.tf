resource "aws_iam_role_policy" "ssm_publish_notifications" {
#   name   = "sns-publish"
#   role   = aws_iam_role.ssm.id
#   policy = data.aws_iam_policy_document.publish_notifications.json
# }