resource "aws_iam_policy" "force-mfa" {
  name        = "tf-force-mfa"
  description = "Enforce MFA authentication"
  policy      = "${data.aws_iam_policy_document.force-mfa.json}"
}