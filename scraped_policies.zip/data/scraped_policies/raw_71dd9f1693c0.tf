data "aws_iam_policy_document" "app_db_pw_secret" {
  statement {
    actions   = ["secretsmanager:GetSecretValue"]
    resources = [aws_secretsmanager_secret.app_db_pw.arn]
  }
}