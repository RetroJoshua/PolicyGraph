resource "aws_iam_role" "auth_role" {
  path                 = "/"
  name                 = "Cognito_sondesAuth_Role"
  assume_role_policy   = data.aws_iam_policy_document.es_auth_role.json
  max_session_duration = 3600
}