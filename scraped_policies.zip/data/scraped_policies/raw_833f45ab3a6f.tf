data "aws_iam_policy_document" "s3_private_log" {
  statement {
    effect    = "Allow"
    actions   = [ "s3:PutObject" ]
    resources = [ "${aws_s3_bucket.s3_private_log.arn}/*" ]
    principals {
      type = "AWS"
      identifiers = [ 
      aws_lb.stg-matsuhub-ecs-front.arn,
      aws_lb.stg-matsuhub-ecs-api.arn
      ]
    }
  }
}