resource "aws_iam_policy" "vector_kinesis_put_policy" {
  name = "vector-kinesis-put-policy"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [{
      Action = [
        "kinesis:*",
      ],
      Effect   = "Allow",
      Resource = aws_kinesis_stream.http_logs_stream.arn
    }]
  })
}