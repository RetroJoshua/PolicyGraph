data "aws_iam_policy_document" "s3" {
  statement {
    sid = "S3Policy"

    actions = [
      "s3:PutObject",
      "s3:GetObject",
      "s3:ListBucket",
    ]

    resources = [
      "arn:aws:s3:::${random_id.s3.hex}",
      "arn:aws:s3:::${random_id.s3.hex}/*",
    ]

    principals = {
      type        = "AWS"
      identifiers = ["${aws_iam_role.codebuild.arn}"]
    }
  }
}