resource "aws_iam_role" "eks_efs_driver_role" {
  depends_on         = [module.eks]
  name               = "xac-efs-csi-driver-role"
  assume_role_policy = <<-EOF
   {
     "Version": "2012-10-17",
     "Statement": [
       {
         "Effect": "Allow",
         "Principal": {
           "Federated": "${module.eks.oidc_provider_arn}"
         },
         "Action": "sts:AssumeRoleWithWebIdentity",
         "Condition": {
           "StringEquals": {
             "oidc.eks.${var.aws_region}.amazonaws.com/id/${basename(module.eks.oidc_provider_arn)}:sub": "system:serviceaccount:kube-system:aws-efs-csi-driver-sa"
           }
         }
       }
     ]
   }
   EOF
}