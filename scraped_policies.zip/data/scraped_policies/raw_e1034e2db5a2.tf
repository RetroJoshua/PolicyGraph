resource "aws_iam_role" "wordpress_task" {
  name               = "${var.site_name}_WordpressTaskRole"
  assume_role_policy = data.aws_iam_policy_document.ecs_assume_role_policy.json
}