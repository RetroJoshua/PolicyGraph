resource "aws_iam_policy" "ec2_secrets_access" {
  name        = "EC2SecretsAccessPolicy"
  description = "Allow EC2 instances to access Secrets Manager"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect : "Allow",
        Action : [
          "secretsmanager:GetSecretValue"
        ],
        Resource : "arn:aws:secretsmanager:${var.region}:${data.aws_caller_identity.current.account_id}:secret:db-password-rds1"
      }
    ]
  })
}