resource "aws_iam_role" "lambda_finalize_clip_embed" {
  name               = "${var.project_name}-finalize-clip-embed"
  assume_role_policy = data.aws_iam_policy_document.lambda_assume.json
  tags               = local.common_tags
}