data "aws_iam_policy_document" "event_target" {
  statement {
    actions = [
      "ecs:RunTask"
    ]
    resources = [
      "${aws_ecs_task_definition.task.arn_without_revision}:*"
    ]
  }
  statement {
    actions = [
      "iam:PassRole"
    ]
    resources = [
      aws_iam_role.task.arn, aws_iam_role.exec.arn
    ]
  }
}