data "aws_iam_policy_document" "sns_queue_iam_document" {
  # Allow SNS to send messages to Queue
  statement {
    # Specifies the actions that SNS can perform on the SQS queue.
    actions   = ["sqs:SendMessage", "sqs:SendMessageBatch"]
    resources = [aws_sqs_queue.cloudtrail_queue.arn]
    effect    = "Allow"

    condition {
      # Specifies that the source ARN must match the CloudTrail SNS topic ARN.
      test     = "ArnEquals"
      variable = "aws:SourceArn"
      values   = [local.cloudtrail_sns_topic_arn]
    }

    principals {
      # Specifies that the principal is the SNS service.
      type        = "Service"
      identifiers = ["sns.amazonaws.com"]
    }
  }
}