resource "aws_iam_role" "ca_iam_role" {
  depends_on = [aws_iam_policy.ca_iam_policy]
  name = "ca-irsa-role-${var.infra_name}"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Effect = "Allow",
        Principal = {
          Federated = aws_iam_openid_connect_provider.oidc_provider.arn
        },
        Action = "sts:AssumeRoleWithWebIdentity",
        Condition = {
          StringEquals = {
            "${local.oidc_provider}:aud" = "sts.amazonaws.com",
            "${local.oidc_provider}:sub" = "system:serviceaccount:kube-system:aws-cluster-autoscaler"
          }
        }
      }
    ]
  })
}