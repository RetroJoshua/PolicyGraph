resource "aws_iam_policy" "snowalert_runtask" {
  name        = "${var.name}-snowalert_runtask"
  description = "${var.name} SnowAlert run task policy"
  policy = <<EOF
{
  "Version": "2012-10-17",
  "Statement": [
    {
      "Effect": "Allow",
      "Action": [
        "ecs:RunTask"
      ],
      "Resource": [
        "${aws_ecs_task_definition.snowalert_runner.arn}"
      ],
      "Condition": {
        "ArnLike": {
          "ecs:cluster": "${aws_ecs_cluster.snowalert_cluster.arn}"
        }
      }
    },
    {
      "Effect": "Allow",
      "Action": "iam:PassRole",
      "Resource": [
        "*"
      ],
      "Condition": {
        "StringLike": {
          "iam:PassedToService": "ecs-tasks.amazonaws.com"
        }
      }
    }
  ]
}
EOF
}