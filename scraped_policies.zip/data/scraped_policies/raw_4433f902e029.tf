data "aws_iam_policy_document" "test_ec2_actions" {
  statement {
    effect    = "Allow"
    resources = ["*"]

    actions = [
      "ec2:StartInstances",
      "ec2:StopInstances",
      "ec2:Describe*"
    ]
  }

  statement {
    effect    = "Deny"
    resources = ["*"]
    actions   = ["ec2:TerminateInstances"]

    condition {
      test     = "IpAddress"
      variable = "aws:SourceIp"
      values   = [chomp(data.http.my_public_ip.response_body)]
    }
  }
}