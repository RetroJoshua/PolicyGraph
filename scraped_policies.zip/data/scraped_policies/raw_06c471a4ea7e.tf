resource "aws_iam_role_policy" "ec2_policy" {
  name = "${var.application}-ec2-policy"
  role = aws_iam_role.ec2_role.name
  policy = jsonencode({
    "Version" : "2012-10-17",
    "Statement" : [
      {
        "Sid" : "efsmount",
        "Effect" : "Allow",
        "Action" : [
          "ssm:DescribeParameters",
          "ssm:GetParameterHistory",
          "ssm:DescribeDocumentParameters",
          "ssm:GetParametersByPath",
          "ssm:GetParameters",
          "ssm:GetParameter",
          "ec2:DescribeTags",
          "iam:PassRole",
          "ec2:*"
        ],
        "Resource" : "*"
      }
    ]
  })
}