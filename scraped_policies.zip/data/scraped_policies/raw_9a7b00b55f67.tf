data "aws_iam_policy_document" "bucket-access" {
  statement {
    sid       = "AllowPublicRead"
    effect    = "Allow"
    resources = ["${aws_s3_bucket.s3-tf-project.arn}/*"]

    principals {
      type        = "*"
      identifiers = ["*"]
    }

    actions = [
      "s3:GetObject",
    ]
  }
  depends_on = [aws_s3_bucket_public_access_block.s3-default-project]
}