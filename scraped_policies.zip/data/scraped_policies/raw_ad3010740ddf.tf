resource "aws_iam_role_policy" "kms" {
  count = try(var.settings.encryption_at_rest.enabled, false) ? 1 : 0
  role  = aws_iam_role.kms[count.index].name
  name  = "kms_access"
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "AllowAtlasToUseKMS"
        Effect = "Allow"
        Action = [
          "kms:Decrypt",
          "kms:DescribeKey",
          "kms:Encrypt",
          "kms:GenerateDataKey",
          "kms:ReEncrypt*",
        ]
        Resource = aws_kms_key.kms[count.index].arn
      }
    ]
  })
}