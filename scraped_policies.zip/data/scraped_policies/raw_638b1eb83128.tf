data "aws_iam_policy_document" "publish_notifications" {
#   statement {
#     actions   = ["sns:Publish"]
#     resources = [aws_sns_topic.this.arn]
#   }
# }