resource "aws_iam_role_policy" "lambda_finalize_clip_embed" {
  name   = "${var.project_name}-finalize-clip-embed"
  role   = aws_iam_role.lambda_finalize_clip_embed.id
  policy = data.aws_iam_policy_document.lambda_finalize_clip_embed.json
}