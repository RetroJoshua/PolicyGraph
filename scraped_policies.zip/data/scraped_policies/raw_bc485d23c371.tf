resource "aws_iam_role" "app" {
	name               = "AppTaskRole"
	assume_role_policy = data.aws_iam_policy_document.ecs-assume-role-policy.json
}