resource "aws_iam_policy" "kms_decrypt_policy" {
  name        = "${var.nombre_lab}_KMSDecryptPolicy"
  description = "Permisos para descifrar usando KMS"

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "kms:Decrypt"
        ],
        Resource = [
          aws_kms_key.postgre_creds_key.arn
        ]
      }
    ]
  })
}