resource "aws_iam_policy" "s3_bucket_access" {
  name   = "${var.name}-nodes-s3-bucket-access"
  policy = data.aws_iam_policy_document.s3_bucket_access.json
}