resource "aws_iam_role" "fis_role" {
  name = "${var.project_name}-fis-role"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "fis.amazonaws.com"
        }
      }
    ]
  })

  tags = {
    Name        = "${var.project_name}-fis-role"
    Environment = var.environment
  }
}