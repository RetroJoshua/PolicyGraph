resource "aws_iam_role" "backstage_task" {
    name               = "${local.name}-task-role"
    assume_role_policy = data.aws_iam_policy_document.ecs_task_assume_role.json
    inline_policy {
        name   = "policy-${local.name}-task-templates"
        policy = data.aws_iam_policy_document.template_bucket_access.json
  }
}