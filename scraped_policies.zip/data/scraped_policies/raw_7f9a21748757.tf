data "aws_iam_policy_document" "kms_assume_role" {
  count = try(var.settings.encryption_at_rest.enabled, false) ? 1 : 0
  statement {
    effect  = "Allow"
    actions = ["sts:AssumeRole"]
    principals {
      type        = "AWS"
      identifiers = [module.project.cloud_provider_setup_aws_account_arn]
    }
    condition {
      test     = "StringEquals"
      values   = [module.project.cloud_provider_setup_aws_external_id]
      variable = "sts:ExternalId"
    }
  }
}