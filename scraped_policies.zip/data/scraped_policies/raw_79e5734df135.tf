data "aws_iam_policy_document" "glue" {
  statement {
    actions   = ["glue:*"]
    effect    = "Allow"
    resources = ["*"]
  }
}