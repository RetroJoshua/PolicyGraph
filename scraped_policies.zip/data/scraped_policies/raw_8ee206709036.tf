resource "aws_iam_role_policy" "sfn" {
  name   = join("-", [local.name, "sfn"])
  role   = aws_iam_role.sfn.id
  policy = data.aws_iam_policy_document.sfn.json
}