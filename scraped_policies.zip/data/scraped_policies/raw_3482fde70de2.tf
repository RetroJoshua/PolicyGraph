resource "aws_iam_role" "cloudformation_permission" {
  name               = "${var.deployment_name}_cf-control"
  assume_role_policy = data.aws_iam_policy_document.cloudformation_permission_assume_role.json
  managed_policy_arns = [
    aws_iam_policy.cloudformation_permission.arn
  ]
}