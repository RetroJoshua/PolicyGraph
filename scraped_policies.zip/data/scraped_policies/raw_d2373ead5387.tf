data "aws_iam_policy_document" "cloudwatch_firehose" {
  statement {
    sid = "DenyAllHTTPRequests"
    effect = "Deny"
    actions = [
      "s3:*"
    ]
    resources = [
      "arn:aws:s3:::${var.s3_bucket_firehose}",
      "arn:aws:s3:::${var.s3_bucket_firehose}/*"
    ]
    principals {
      type = "AWS"
      identifiers = ["*"]
    }
    condition {
      test     = "Bool"
      values   = ["false"]
      variable = "aws:SecureTransport"
    }
  }
}