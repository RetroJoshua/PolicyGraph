resource "aws_iam_role" "rol_SSM" {
  name = "${var.nombre_lab}_rol_SSM"

  assume_role_policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Action = "sts:AssumeRole"
        Effect = "Allow"
        Principal = {
          Service = "ec2.amazonaws.com"
        }
      }
    ]
  })

  tags = merge(var.tags, {
    Name = "Rol-SSM-Lab4"
  })
}