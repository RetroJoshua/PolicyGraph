resource "aws_iam_role_policy" "ec2_instance_connect_policy" {  # [Added]
  name = "EC2InstanceConnectPolicy"
  role = aws_iam_role.ssm_role.name

  policy = jsonencode({
    Version = "2012-10-17",
    Statement = [
      {
        Effect = "Allow",
        Action = [
          "ec2-instance-connect:SendSSHPublicKey"  # [Added]
        ],
        Resource = "*"
      }
    ]
  })
}