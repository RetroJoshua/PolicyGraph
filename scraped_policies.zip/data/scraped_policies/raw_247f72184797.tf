resource "aws_iam_policy" "sso_permission_boundary" {
  provider = aws.iam

  name        = "SSOPermissionBoundary"
  policy      = data.aws_iam_policy_document.iam_admin_perm_boundary.json
  description = "Restricts an IAM Identity Center administrator from escalating privileges"
}