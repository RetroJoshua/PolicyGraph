resource "aws_iam_role_policy" "lambda_start_frame_task" {
  name   = "${var.project_name}-start-frame-task"
  role   = aws_iam_role.lambda_start_frame_task.id
  policy = data.aws_iam_policy_document.lambda_start_frame_task.json
}