resource "aws_iam_role_policy" "k3s_ssm_put" {
  name = "${var.project}-k3s-ssm-put"
  role = aws_iam_role.k3s.id

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [{
      Effect   = "Allow"
      Action   = "ssm:PutParameter"
      Resource = "arn:aws:ssm:${var.region}:*:parameter/${var.project}/k3s/*"
    }]
  })
}