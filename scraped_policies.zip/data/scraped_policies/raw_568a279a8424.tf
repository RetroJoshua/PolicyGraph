resource "aws_iam_role_policy" "clip_pegasus_worker_task" {
  name   = "${var.project_name}-clip-pegasus-task"
  role   = aws_iam_role.clip_pegasus_worker_task.id
  policy = data.aws_iam_policy_document.clip_pegasus_worker_task.json
}