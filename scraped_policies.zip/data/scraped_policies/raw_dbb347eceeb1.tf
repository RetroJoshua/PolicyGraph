resource "aws_iam_role_policy" "lambda_start_clip_embed" {
  name   = "${var.project_name}-start-clip-embed"
  role   = aws_iam_role.lambda_start_clip_embed.id
  policy = data.aws_iam_policy_document.lambda_start_clip_embed.json
}